// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		�҂��҂�񃁁[�^�[
//
//		
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// =========================================================
// 
// ---------------------------------------------------------

//�c�P�Vpx


#inc_start

#define	@meter_app_time		@time_sys
#define	@meter_set_pos_x	-530		// �������W�i�B��Ă�
#define	@meter_set_pos_y	10
#define	@meter_app_pos		10
#define	@meter_app_range_x	210
#define	@meter_app_range_y	300

#define	@meter_v_pos_x		60

#define	@meter_mask_pos_x	10
#define	@meter_mask_pos_y	15
#define	@meter_mask_no		0


#define	@pyon_set_pos_x		(1152 - 481)/2
#define	@pyon_set_pos_y		(720 - 269)/2

#define	@pyon_v_pos_x		-350

#define	@pyon_mask_no		1
#define	@pv					3	//���є��x�[�X child[ ]
#define	@v_pos_x			169
#define	@v_pos_y			266
#define	@vb_space			12
#define @v_fade_time		200
#define	@v_fall_time		500
#define	@v_fall_way			2400 //�����鋗���F�{��
#define	@v_fall_dis			30	//�����鋗���F���Z
#define	@v_fall_rev			100 //�����鋗���F�␳�l
#define @v_delay			20	//���є��̗����J�n�̒x��

#define	@pyon_slide_way		200
#define	@pyon_slide_time	500

#define	@pyon_slide_way2	400

#define	@v_height			17

#define @jump_cut_time		400
#define	@jump_fade_time		200
#define @jump_interval		50

#define	@pyon_after_time	500

#property $inc_ch_pt


#inc_end


#z00






command $meter_stand(property $i){

	mask[@meter_mask_no].create(_pyon_meter_frame_mask)
	mask[@meter_mask_no].x = @meter_mask_pos_x
	mask[@meter_mask_no].y = @meter_mask_pos_y

	front.object[@obj_no_meter].init
	front.object[@obj_no_meter].disp = $i
	front.object[@obj_no_meter].set_pos(@meter_set_pos_x, @meter_set_pos_y)
	front.object[@obj_no_meter].tr = 255
	front.object[@obj_no_meter].wipe_copy = 1
	front.object[@obj_no_meter].layer = @lay_no_meter
	front.object[@obj_no_meter].child.resize(5)
	
	// �w�i
	front.object[@obj_no_meter].child[0].create(_pyon_meter_bg, 1, 20, 22)
	
	// ����
	front.object[@obj_no_meter].child[1].init
	front.object[@obj_no_meter].child[1].disp = 1
	front.object[@obj_no_meter].child[1].child.resize(1)
	front.object[@obj_no_meter].child[1].mask_no = @meter_mask_no
	front.object[@obj_no_meter].child[1].child[0].create(_pyon_meter_stage, 1, -100, 25)
	
	// �L�����|�C���g�̌���
	$meter_chara_all(2, @obj_no_meter, @meter_v_pos_x, -1)
	
	// ����
	front.object[@obj_no_meter].child[4].init
	front.object[@obj_no_meter].child[4].disp = 1
	front.object[@obj_no_meter].child[4].child.resize(2)
	front.object[@obj_no_meter].child[4].child[0].create(_pyon_meter_frame, 1, 0, 8)
	front.object[@obj_no_meter].child[4].child[1].create(_pyon_meter_title, 1, 100, 0)
	
}


command $meter_watch(property $i){

	if($i){
		frame_action_ch[@frame_action_ch_no_meter].start(-1, "$meter_disp")
//		@meter_load = 1
	}
	else{
		frame_action_ch[@frame_action_ch_no_meter].end
//		front.object[@obj_no_meter].tr = 0
//		@meter_load = 0
	}

}

command $meter_disp(property $fa:frameaction){

	// ���ݒn
	l[10] = front.object[@obj_no_meter].x
	// ���ݒn�_����ړI�n�ւ̕K�v����
	l[12] = @meter_app_time * (@meter_app_pos - l[10]) / (@meter_app_pos - @meter_set_pos_x)
	l[11] = @meter_app_time * (l[10] - @meter_set_pos_x) / (@meter_app_pos - @meter_set_pos_x)
	d[0] = l[11]
	d[1] = l[12]
	
	l[13] = front.object[@obj_no_meter].tr
	
	if(@meter_excall){
		front.object[@obj_no_meter].disp = 0
		front.object[@obj_no_meter].x = @meter_set_pos_x
	}
	elseif(@meter_section == 0){	// ��������̔�\��
		front.object[@obj_no_meter].disp = 0
//		front.object[@obj_no_meter].x = @meter_set_pos_x
	}
	elseif(@meter_sel){		// �I�𒆁F��\��
		front.object[@obj_no_meter].disp = 0
//		front.object[@obj_no_meter].x = @meter_set_pos_x
	}
	else{
		front.object[@obj_no_meter].disp = 1
	}
		
		// �\���͈͓��Ƀ}�E�X�J�[�\��������ꍇ
		if(mouse.get_pos_x < @meter_app_range_x && mouse.get_pos_y < @meter_app_range_y){
		

			// �\������Ă��Ȃ������ꍇ
			if(@meter_load == 0){
				front.object[@obj_no_meter].frame_action.start(l[12], "$meter_nyu", l[10], @meter_app_pos, l[12])
			@meter_load = 1
			}
		}
		else{
		
			if(@meter_load == 1){
				front.object[@obj_no_meter].frame_action.start(l[11], "$meter_nyu", l[10], @meter_set_pos_x, l[11])
			@meter_load = 0
			}
		}

	
}



command $meter_nyu(
	property $fa:frameaction,
	property $obj:object,
	property $start_x,
	property $end_x,
	property $start_time){

	l[0] = $fa.counter.get
	l[1] = math.timetable(l[0], 0, $start_x, [0, $start_time, $end_x, 2])
	mask[@meter_mask_no].x = l[1]
	$obj.x = l[1]
	$meter_chara_all(2, @obj_no_meter, @meter_v_pos_x, -1)
}

command $meter_chara_all(property $i, property $obj_no, property $pos_x, property $ch){

	// �y��
	front.object[$obj_no].child[$i].init
	front.object[$obj_no].child[$i].disp = 1
	front.object[$obj_no].child[$i].child.resize(4)
	front.object[$obj_no].child[$i].y = 265
	front.object[$obj_no].child[$i].x = $pos_x
	
	// �L�����y��
	for(l[0] = 0, l[0] < 4, l[0] += 1){
	
		front.object[$obj_no].child[$i].child[l[0]].init
		front.object[$obj_no].child[$i].child[l[0]].disp = 1
		if(l[0] == $ch){
			front.object[$obj_no].child[$i].child[l[0]].disp = 0
		}
		front.object[$obj_no].child[$i].child[l[0]].child.resize(4)
		front.object[$obj_no].child[$i].child[l[0]].x = 100 * l[20]
		if(l[0] != $ch){ l[20] += 1 }
		
		if($ch_point(l[0]) < 3){
			l[10] = - 200
		}
		else{
			l[10] = - 50
		}
		
		front.object[$obj_no].child[$i].child[l[0]].child[2].create(_pyon_point, 1, -14, l[10], $ch_point(l[0]))
		if($ch >= 0){
			front.object[$obj_no].child[$i].child[l[0]].child[2].disp = 0
		}
			
		// �L����+���є�[1]�Ɣ��g[0]�̓y��
		for(l[1] = 0, l[1] < 2, l[1] += 1){
		
			// �L����[1]�ƒ��є�[0]
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].init
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].disp = 1
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child.resize(2)
			// ���̒��g
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].init
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].disp = 1
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child.resize(2)
		
			// �L����
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child[1].create(_pyon_meter_ch, 1, 28, -30 - @v_height * $ch_point(l[0]), 4 + l[0] * 8 + l[1])
			
			if($ch_point(l[0]) >= 3){
				front.object[$obj_no].child[$i].child[l[0]].child[3].create(_pyon_heart, 1)
				front.object[$obj_no].child[$i].child[l[0]].child[3].set_pos(-18, - 106 - @v_height * $ch_point(l[0]))
			}
			if($ch_point(l[0]) > 0 && $ch_point(l[0]) >= $ch_point(0) && $ch_point(l[0]) >= $ch_point(1) && $ch_point(l[0]) >= $ch_point(2) && $ch_point(l[0]) >= $ch_point(3)){
				front.object[$obj_no].child[$i].child[l[0]].child[1 -l[1]].child[1].patno += 2
			}
			
			// ���є�
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child[0].init
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child[0].disp = 1
			front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child[0].child.resize($ch_point(l[0]) + 1)
			
			for(l[2] = 0, l[2] < $ch_point(l[0]) + 1, l[2] += 1){
				front.object[$obj_no].child[$i].child[l[0]].child[1 - l[1]].child[0].child[l[2]].create(_pyon_meter_vault, 1, 0, -@v_height * ($ch_point(l[0]) - l[2]), l[2] + l[1] * 7)
			}
		}
	}
}

command $ch_point(property $i):int{

	l[0] = @prefer_start($i)//a[@013_1 + $i] + a[@021_1 + $i] + a[@021_2 + $i] + a[@031_1 + $i] + a[@101_1 + $i]
	
	return(l[0])
}


command $pyon_stage(property $ch_num){

	counter[0].start
	$pyon_stand($ch_num)
	counter[0].wait(@v_fall_time + @jump_cut_time * 3 + @pyon_slide_time + @pyon_after_time)
	wipe

}

command $pyon_stand(property $ch_num){

//	counter[0].start

	mask[@pyon_mask_no].create(_pyon_meter_frame_mask)
	mask[@pyon_mask_no].x = @pyon_set_pos_x
	mask[@pyon_mask_no].y = @pyon_set_pos_y + 7
	
	$inc_ch_pt = $ch_point($ch_num)
	
	// �y��
	front.object[@obj_no_pyon].init
	front.object[@obj_no_pyon].layer = @lay_no_meter
	front.object[@obj_no_pyon].disp = 1
	front.object[@obj_no_pyon].child.resize(6)
	front.object[@obj_no_pyon].set_pos(@pyon_set_pos_x, @pyon_set_pos_y)
	
	//4-����
	front.object[@obj_no_pyon].child[4].init
	front.object[@obj_no_pyon].child[4].disp=1
	front.object[@obj_no_pyon].child[4].child.resize(2)
	front.object[@obj_no_pyon].child[4].child[1].create(_pyon_meter_title, 1, 100, 0)
	front.object[@obj_no_pyon].child[4].child[0].create(_pyon_meter_frame, 1, 0, 8)
	//front.object[@obj_no_pyon].child[4].child[0].frame_action.start(@jump_cut_time * 3 + @v_fall_time, $


	//3-���є�
	front.object[@obj_no_pyon].child[@pv].init
	front.object[@obj_no_pyon].child[@pv].disp=1
	front.object[@obj_no_pyon].child[@pv].mask_no = @pyon_mask_no
	front.object[@obj_no_pyon].child[@pv].child.resize(4)
	front.object[@obj_no_pyon].child[@pv].set_pos(@v_pos_x, @v_pos_y)
	
	front.object[@obj_no_pyon].child[@pv].frame_action.start(@jump_cut_time * 3 + @v_fall_time + @pyon_slide_time, "$pyon_jump_after", @v_pos_x, @v_pos_x + @pyon_slide_way)
	
	// ���o
	front.object[@obj_no_pyon].child[@pv].child[3].create(_pyon_meter_amb, 1, 0, -110, 0)
	front.object[@obj_no_pyon].child[@pv].child[3].tr = 255
	front.object[@obj_no_pyon].child[@pv].child[3].frame_action.start(300 + @jump_cut_time * 3 + @v_fall_time, "$pyon_jump_amb")

	for(l[0] = 0, l[0] < 2, l[0]+= 1){
		//�ʏ함
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].init
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].disp=1
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child.resize(4)
		//���o��
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[3].init
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[3].disp=1
		//�L�����N�^
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[2].init
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[2].disp=1
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[2].create(_pyon_meter_ch, 1, 94 + @vb_space + $inc_ch_pt, -15, l[0] + $ch_num * 8)
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[2].frame_action_ch.resize(6)
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[2].frame_action_ch[0].start(@jump_cut_time * 3 + @v_fall_time, "$pyon_jump_ev", $ch_num)
		//���ݐ؂��
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[1].create(_pyon_meter_board, 1, 70 + @vb_space + $inc_ch_pt, -18, l[0])
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[1].frame_action_ch.resize(2)
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[1].frame_action_ch[0].start(@v_fall_time, "$pyon_board_fall", $inc_ch_pt)
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[1].frame_action_ch[1].start(@v_fade_time, "$pyon_fade_in", @v_fade_time, 0)
		//���є�
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[0].init
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[0].disp=1
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[0].frame_action.start(@v_fade_time, "$pyon_fade_in", @v_fade_time, 0)
		front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[0].child.resize($inc_ch_pt + 1)
		for(l[10] = 0, l[10] < $inc_ch_pt + 1, l[10] += 1){
			front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[0].child[l[10]].create(_pyon_meter_vault, 1, 0, -17*($inc_ch_pt - l[10]), l[10] + l[0] * 7)
			front.object[@obj_no_pyon].child[@pv].child[1 - l[0]].child[0].child[l[10]].frame_action.start(@v_fall_time + l[10] * @v_delay, "$pyon_vault_fall", @v_fall_way, 1000, l[10], $inc_ch_pt, @v_fall_time)
		}
	}
	
	//2-���̑��L����
	$meter_chara_all(2, @obj_no_pyon, @pyon_v_pos_x, $ch_num)

	front.object[@obj_no_pyon].child[2].mask_no = @pyon_mask_no
	front.object[@obj_no_pyon].child[2].frame_action.start(@jump_cut_time * 3 + @v_fall_time + @pyon_slide_time, "$pyon_jump_after", @pyon_v_pos_x, @pyon_v_pos_x + @pyon_slide_way2)



	//1-����
	front.object[@obj_no_pyon].child[1].init
	front.object[@obj_no_pyon].child[1].child.resize(1)
	front.object[@obj_no_pyon].child[1].disp = 1
	front.object[@obj_no_pyon].child[1].mask_no = @pyon_mask_no
	front.object[@obj_no_pyon].child[1].child[0].create(_pyon_meter_stage, 1, -110, 25)

	//0-�w�i
	front.object[@obj_no_pyon].child[0].create(_pyon_meter_bg, 1, 20, 22)

}

command $pyon_fade_in(
	property $fa :frameaction,
	property $obj : object,
	property $time,
	property $delay
	)
{
	l[0] = $fa.counter.get
	$obj.tr = math.timetable(l[0], $delay, 0, [0, $time, 255, 2])
}

command $pyon_jump_fade_in(
	property $fa :frameaction,
	property $obj : object
	)
{
	l[0] = ($fa.counter.get - @v_fall_time) % @jump_cut_time
	$obj.tr = math.timetable(l[0], 0, 0, [0, @jump_fade_time, 255, 2])
	a[0] = l[0]
}


command $pyon_vault_fall(
	property $fa : frameaction,
	property $obj : object,
	property $start,
	property $end,
	property $step,
	property $ch_pt,
	property $time)
{
	l[2] = -$step * @v_delay
	l[0] = $fa.counter.get
	l[1] = math.timetable(l[0], l[2], $start, [0, $time, $end, 1])
	$obj.y = -17 * ($ch_pt - $step) * l[1] / 1000 
	$obj.y += math.timetable(l[0], l[2], - @v_fall_rev, [0, $time, 0, 1])

/*
	l[0] = $fa.counter.get
	l[1] = -17 * ($ch_pt - $step) - @v_fall_dis * $step	// ����
	l[2] = -17 * ($ch_pt - $step)	// �I��
	l[3] = @v_fall_time - @v_delay * ($ch_pt - $step)
	l[4] = 
	$obj.y = math.timetable(l[0], 0, l[1], [l[3], l[4], l[2], 2])
*/
}

command $pyon_board_fall(
	property $fa : frameaction,
	property $obj: object,
	property $ch_pt)
{
	l[0] = $fa.counter.get
	$obj.y = math.timetable(l[0], -($ch_pt) * @v_delay, - @v_fall_rev - 18, [0, @v_fall_time, -18, 1])
}


command $pyon_jump_ev(
	property $fa :frameaction,
	property $obj : object,
	property $ch_num)
{
	l[0] = $fa.counter.get
	l[1] = ($fa.counter.get - @v_fall_time) % @jump_cut_time
	$obj.tr = math.timetable(l[1], 0, 0, [@jump_interval, @jump_fade_time, 255, 2])
	if(l[0] <= @v_fall_time + @jump_cut_time){
		$obj.x = math.sin(math.timetable(l[0], @v_fall_time, 1800, [0, @jump_cut_time, 2700, 1]), 40) + 152
		$obj.y = math.cos(math.timetable(l[0], @v_fall_time, 1800, [0, @jump_cut_time, 2700, 1]), 20) - 14
	}
	elseif(@v_fall_time + @jump_cut_time + 100< l[0] && l[0] <= @v_fall_time + @jump_cut_time * 2){
		if($obj.patno - $ch_num * 8 < 2){
			$obj.patno += 2
		}
		$obj.x = math.sin(math.timetable(l[0], @v_fall_time + @jump_cut_time, 900, [0, @jump_cut_time, 1800]), 5) * 2 + 100
		$obj.y = math.cos(math.timetable(l[0], @v_fall_time + @jump_cut_time, 900, [0, @jump_cut_time, 1800]), 20) - 38 - $inc_ch_pt * 17 / 2 + (12 - $inc_ch_pt)
	}
	elseif(@v_fall_time + @jump_cut_time * 2 < l[0] && l[0] < @v_fall_time + @jump_cut_time * 3-1){
		if($obj.patno - $ch_num * 8 < 4){
			$obj.patno += 2
		}
		$obj.x = 27 + math.sin(math.timetable(l[0], @v_fall_time + @jump_cut_time * 2, 900, [0, @jump_cut_time, 1800]), 14 - $inc_ch_pt)/2
		$obj.y = -33 - $inc_ch_pt * 17 + math.cos(math.timetable(l[0], @v_fall_time + @jump_cut_time * 2, 1800, [0, @jump_cut_time, 2700]), 14 - $inc_ch_pt * 2)/2
	}
	elseif(@v_fall_time + @jump_cut_time * 3 -1 <= l[0]){
		$obj.tr = 255
		$obj.x = 27
		$obj.y = -33 - $inc_ch_pt * 17
	}
}

command $pyon_jump_amb(
	property $fa:frameaction,
	property $obj:object)
{
	l[0] = $fa.counter.get

	if(@v_fall_time + @jump_cut_time < l[0] &&l[0] <= @v_fall_time + @jump_cut_time + 100){
		$obj.tr = 255
		$obj.x =  74
		$obj.y =  - 28
		
	}
	elseif(@v_fall_time + @jump_cut_time + 100< l[0] && l[0] <= @v_fall_time + @jump_cut_time +400){
		$obj.tr = 255
		$obj.x = 150
		$obj.y = - 38 - $inc_ch_pt * 4
		$obj.patno = 1
	}
	elseif(@v_fall_time + @jump_cut_time * 3 -20 < l[0] && l[0] <= @v_fall_time + @jump_cut_time * 3 + 200){
		$obj.tr = 255
		$obj.x = 10
		$obj.y = - $inc_ch_pt * 17 - 33
		$obj.patno = 2
	}
	else{
		$obj.tr = 0
	}

}
command $pyon_jump_after(
	property $fa :frameaction,
	property $obj :object,
	property $start_x,
	property $end_x)
{
	
	l[0] = $fa.counter.get
	l[1] = math.timetable(l[0], @jump_cut_time * 3 + @v_fall_time, $start_x, [0, @pyon_slide_time, $end_x, 0])
	$obj.x = l[1]
}
	