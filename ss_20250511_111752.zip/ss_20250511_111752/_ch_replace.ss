#z00
// �\��u������
command $ch_face_replace(property $name:str, property $face:str, property $pose:str, property $k:str):str{



	if($name == "no"){			// �m�m
		if($face == "guru"){
			$face = "919191"
		}
		if($face == "gunu"){
			$face = "030406"
		}
		if($face == "kira"){
			$face = "010105"
		}
		if($face == "guruguru"){
			$face = "919191"
		}
		if($face == "gurusuppa"){
			$face = "919181"
		}
		if($face == "suppa"){
			$face = "919281"
		}
		if($face == "suppa1"){
			$face = "110581"
		}
		if($face == "hin"){
			$face = "pokan"
		}
	}
	elseif($name == "ru"){
		if($face == "hin"){
			$face = "pokan"
		}
	}
	elseif($name == "ri"){			// �z
		if($face == "gan"){
			$face = "248108"
		}
		if($face == "gannaki"){
			$face = "020207"
		}
		if($face == "gannaki0"){
			$face = "020708"
		}
		if($face == "gannaki2"){
			$face = "020707"
		}
		if($face == "gannaki3"){
			$face = "020706"
		}
		if($face == "pokan"){
			$face = "248108"
		}
		if($face == "sirome"){
			$face = "218108"
		}
		if($face == "ninmari" && $pose.left(1) == "b"){
			$face = "010401"
		}
		if($face == "kakushigoto"){
			$face = "020608"
		}
		if($face == "kakushigoto4"){
			$face = "020604"
		}
	}
	elseif($name == "mi"){			// �݂邭
		if($pose.left(1) == "b"){
			if($face == "shun"){
				$face = "020303"
			}
		}
		if($face == "hawawa"){
			$face = "029208"
		}
		if($face =="awaawa"){
			$face = "210209"
		}
	}
	elseif($name == "ki"){			// �e���
		if($face == "pun"){
			$face = "031419"
		}
	}


	l[0] = $face.tonum
	if(l[0] > 0){	// ���l�̕�����w�肾�����ꍇ
		l[1] = l[0] / 10000		// brow
		l[2] = l[0] / 100 % 100	// eye
		l[3] = l[0] % 100		// mouth
	}
	else{
		l[0] = database[3].find_str(0, $face)
		l[1] = database[3].get_num(l[0], 1)
		l[2] = database[3].get_num(l[0], 2)
		l[3] = database[3].get_num(l[0], 3)
	}
	
	if($name == "ru" && $pose.left(1) == "b"){
		if(l[2] == 6){ l[2] = 5 }
	}
	if($name == "ri" && $pose.left(1) == "b"){
		if(l[2] == 6){ l[2] = 4 }
	}
	if($name == "ki"){
		if(l[2] == 3){ l[2] = 1 }
	}
	
	
	k[10] = $k + "brw_" + math.tostr_zero(l[1], 2)
	k[11] = $k + "eye_" + math.tostr_zero(l[2], 2)
	k[12] = $k + "mth_" + math.tostr_zero(l[3], 2)
	
if(@kakunin){
	
	// �t�@�C���s���ݎ��̏���
	k[20] = "g00\\" + k[10] + ".g00"
	k[21] = "g00\\" + k[11] + ".g00"
	k[22] = "g00\\" + k[12] + ".g00"
	
	if(system.check_file_exist(k[20]) != 1){
		k[10] = "_null"
	}
	if(system.check_file_exist(k[21]) != 1){
		k[11] = "_null"
	}
	if(system.check_file_exist(k[22]) != 1){
		k[12] = "_null"
	}
}	
	
	k[0] = k[10] + "|" + k[11] + "|" + k[12]
//	k[0] = $k + "brw_" + math.tostr_zero(l[1], 2)
//	k[0] += "|" + $k + "eye_" + math.tostr_zero(l[2], 2)
//	k[0] += "|" + $k + "mth_" + math.tostr_zero(l[3], 2)
	
	if(($name == "ri" && $pose == "a2") && (l[3] == 2 || l[3] == 5 || l[3] == 7 || l[3] == 12)){
		k[0] += "_"
	}
	
	return(k[0])
	
}


// �e�X�g�p
command $ch_pose_replace(property $name:str, property $dress:str, property $pose:str):str
{

//	if(@kakunin_isho == 0){ return($pose) }
//	if($pose.left(1) == "a"){ return($pose) }
	
	k[0] = $pose
	
	if($name == "no"){
		if($dress.left(3) == "onp" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "onn" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "stg" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "pjm" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "dog" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "fox" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "ssk" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "mzg" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "ykt" && $pose.left(1) == "b"){ k[0] = "a2" }
	}
	if($name == "ru"){
		if($dress.left(3) == "pnt" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "pjm"){ k[0] = "a1" }
		if($dress.left(3) == "pjt" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "ykt" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "ony" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "mtn"){ k[0] = "a2" }
		if($dress.left(3) == "tgh" && $pose.left(1) == "b"){ k[0] = "a2" }
	}
	if($name == "ri"){
		if($dress.left(3) == "gth" && $pose.left(1) == "b"){ k[0] = "a1" }
		if($dress.left(3) == "kcm" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "kcp" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "scm" && $pose.left(1) == "b"){ k[0] = "a2" }
		if($dress.left(3) == "ykt" && $pose.left(1) == "b"){ k[0] = "a1" }
	}
	if($name == "mi"){
		if($dress == "na" && $pose.left(1) == "b"){ k[0] = "a3" }
		if($dress.left(3) == "hal" && $pose.left(1) == "b"){ k[0] = "a3" }
		if($dress.left(3) == "stg" && $pose.left(1) == "b"){ k[0] = "a3" }
		if($dress.left(3) == "stu" && $pose.left(1) == "b"){ k[0] = "a3" }
		if($dress.left(3) == "pjm" && $pose.left(1) == "b"){ k[0] = "a3" }
		if($dress.left(3) == "pjc" && $pose.left(1) == "b"){ k[0] = "a3" }
//		if($dress.left(3) == "gyw" && $pose.left(1) == "b"){ k[0] = "a3" }
		if($dress.left(3) == "ykt" && $pose.left(1) == "b"){ k[0] = "a3" }
	}
	if($pose.right(1) == "u" || $pose.right(1) == "b" || $pose.right(1) == "h"){
		k[0] = k[0].left(2) + $pose.right(1)
	}

	return(k[0])
	
}

// �e�X�g�p
command $ch_dress_replace(property $name:str, property $dress:str, property $pose:str):str{

	if(@kakunin_isho == 0){ return($dress) }

	k[0] = $dress
	
	if($name == "no"){
		return(k[0])
		if($dress.left(3) == "blm"){ k[0] = "na" }
		if($dress.left(3) == "ykt"){ k[0] = "na" }
		if($dress.left(3) == "btw"){ k[0] = "na" }
		if($dress.left(3) == "mzg"){ k[0] = "na" }
		if($dress.left(3) == "ssk"){ k[0] = "na" }
		if($dress.left(3) == "stg"){ k[0] = "na" }
		if($dress.left(3) == "dog"){ k[0] = "na" }
		if($dress.left(3) == "pnt" && $pose.left(1) == "b"){ k[0] = "na" }
	}
	if($name == "ru"){
		return(k[0])
//		if($dress.left(3) == "gym"){ k[0] = "na" }
		if($dress.left(3) == "ykt"){ k[0] = "na" }
		if($dress.left(3) == "ony"){ k[0] = "na" }
		if($dress.left(3) == "btw"){ k[0] = "na" }
//		if($dress.left(3) == "pjm"){ k[0] = "na" }
		if($dress.left(3) == "mtn"){ k[0] = "na" }
	}
	if($name == "ri"){
		return(k[0])
//		if($dress.left(3) == "gym"){ k[0] = "na" }
		if($dress.left(3) == "ykt"){ k[0] = "na" }
		if($dress.left(3) == "pjm"){ k[0] = "na" }
		if($dress.left(3) == "pnt" && $pose.left(1) == "b"){ k[0] = "na"}
	}
	if($name == "mi"){
//		if($dress.left(3) == "gym"){ k[0] = "na" }
	}
		
	return(k[0])
}

