// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		��z�V�[��
//		
//		
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

#inc_start

	// ���ڐ�
	#define		@sc_items		4
	
	// �I�u�W�F�N�g�Ȃ�΁[
	#define		@obj_bg			0
	#define		@obj_frame		1
	#define		@obj_close		2
	
	
	
	// �ڂ���Ȃ�΁[
	#define		@btn_close		-1
	
	#define		@btn_no			10
	#define		@btn_ru			11
	#define		@btn_ri			12
	#define		@btn_mi			13
	
	// ���W
	#define		@th_pos_x		130
	#define		@th_pos_y		158
	#define		@clip_left		120
	#define		@clip_top		158
	#define		@clip_right		1000
	#define		@clip_bottom	632
	
	#define		@space_wid		150
	#define		@space_ver		100
	
	#define		@rail_pos_y		100
	#define		@rail_region	463
	
	#property	$line					// �T���l�C���̍s��
	#property	$th_region
	#define		$th_pos			g[061]
	#property	$push_btn_no
	#property 	$push_mouse_y
	#property	$push_btn_y
	
//	@kaiso_slide_pos	g[061]
#inc_end



#z00
@bgm(asa)
set_title(�ӏ܃��j���[)
$kaiso_menu_disp

wipe

front.objbtngroup[0].init
front.objbtngroup[0].start_cancel

while(1){

//	$update_object(1)
	
	l[2] = front.objbtngroup[0].get_decided_no

	
	// �V�[���̃{�^���������ꂽ�ꍇ
	if(@btn_no == l[2]){
		$replay("sc213_�m�m�T�F�v�[���J��", 10, "�m�m�̃v�[���J��")
	}
	if(@btn_ru == l[2]){
		$replay("sc226_�ڗ��W�F�V���n", 10, "�ڗ����ƃ����[�S�[�����h")
	}
	if(@btn_ri == l[2]){
		$replay("sc132_�z�Q�F���l��", 10, "�z�Ɓc")
	}
	if(@btn_mi == l[2]){
		$replay("sc242_�݂邭�S�F���R����", 10, "�݂邭�̎��R����")
	}
	
	if(l[2] == @btn_close){
		break
	}
	
	if(l[2] >= 0){
		front.objbtngroup[0].init
		front.objbtngroup[0].start_cancel
	}
	disp
	f[0] += 1
}

return




// =========================================================
// ��z���j���[
// ---------------------------------------------------------
command $kaiso_menu_disp{

	// �w�i
	back.object[@obj_bg].init
	back.object[@obj_bg].disp = 1
	back.object[@obj_bg].child.resize(4)
	back.object[@obj_bg].child[0].create(bgi07, 1, 1152/2, 720/2)
	back.object[@obj_bg].child[1].create(_config_bg_filter, 1)//_rect(0,0, 1152,729, 58,55,88, 74, 1)
//	back.object[@obj_bg].child[2].create(_msgbk_filter, 1)
	
	// ����A�߂�{�^��
	back.object[@obj_close].create(_msgbk_btn_close, 1, 1087, 640)
	back.object[@obj_close].set_button(@btn_close, 0, 2, 0)
	
	back.object[@btn_no].create(ev213_pool_01, 1, 246-848, 60)
	back.object[@btn_no].set_src_clip(1, 848, 0, 848+150, 600)
	back.object[@btn_no].set_button(@btn_no, 0, 2, 0)

	back.object[@btn_ru].create(ev226_merry_01, 1, 246+170-325, 60)
	back.object[@btn_ru].set_src_clip(1, 325, 0, 325+150, 600)
	back.object[@btn_ru].set_button(@btn_ru, 0, 2, 0)

	back.object[@btn_ri].create(ev132_first_01, 1, 246+170+170-723, 60)
	back.object[@btn_ri].set_src_clip(1, 723, 0, 723+150, 600)
	back.object[@btn_ri].set_button(@btn_ri, 0, 2, 0)
	
	back.object[@btn_mi].create(ev242_research_01, 1, 246+170+170+170-380, 60)
	back.object[@btn_mi].set_src_clip(1, 380, 0, 380+150, 600)
	back.object[@btn_mi].set_button(@btn_mi, 0, 2, 0)
}


// =========================================================
// �V�[���ӏ�
// ---------------------------------------------------------
command $th_sc(property $i){


/*	
	if(@clear_nono){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		stage[$i].object[@obj_th].child[l[0]].child[1].create(th_end, 1, 0, 0, 0)
		stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_ed_start, 0, 2, 0)
		
		l[0] += 1
	}
*/



	
	// @clear_milk
}

command $replay(property $ss:str, property $z, property $cap:str){

	bgm.stop(1000)
	syscom.set_save_enable_flag(0)
	syscom.set_load_enable_flag(0)
	$mwnd_btn_blind_view
	script.set_hide_mwnd_enable
	syscom.set_hide_mwnd_enable_flag(1)
	syscom.set_syscom_menu_enable
	script.set_msg_back_enable
	script.set_ctrl_skip_enable
	@kaiso_chu = 1
	// 0:flag_no 1:th_name
	k[0] = $ss
	l[0] = $z
	k[1] = $cap
	set_title(k[1])
	@bgv_no
	@bgv_ru
	@bgv_ri
	@bgv_mi
	$mwnd_btn_load = 1
	$mwnd_btn_watch(1)
	$mwnd_btn_blind_view
	farcall(k[0], l[0])
	
	returnmenu
}


