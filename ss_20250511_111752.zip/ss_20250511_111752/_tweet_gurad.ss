#z00
// �c�C�[�g���s���F���i�ŏC���p�b�`�d�l�i�t���O�͑̌��łƂ͕ʁj
command $tweet_guard{

	if(front.object[@obj_no_bg].exist_type == 1){
		k[0] = front.object[@obj_no_bg].get_file_name
	}
	
	if(k[0] != ""){
		k[1] = k[0].left(k[0].cnt - 3)		// �������O
		k[2] = k[0].left(5)					// ����
		k[3] = k[1].right(k[1].cnt - 6)		// ���e
		k[4] = k[0].right(2)
		l[1] = k[4].tonum			// ��������
	}

// front[@obj_no_bg]��ev�Ŏn�܂�Ƃ��A�����֎~
	if(k[0].left(2) == "ev"){
		// ���̎��A�ꕔ��CG�͋���
		// ����ڂ̋��s����
		if(k[2] == "ev011"){
			if(k[3] == "educate"){
				l[20] = 1
			}
			elseif(k[0] == "ev011_podium_98" && front.object[@obj_no_st].exist_type == 1){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[2] == "ev012"){
			if(k[3] == "furo"){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[2] == "ev013"){
			if(k[3] == "nono"){
				if(l[1] == 1 || l[1] == 2 || l[1] == 51 || l[1] == 52){
					l[20] = 0
				}
				else{
					l[20] = 1
				}
			}
			elseif(k[3] == "rin2"){
				if(l[1] <= 6){
					l[20] = 0
				}
				else{
					l[20] = 1
				}
			}
			elseif(k[3] == "ruri"){
				if(l[1] > 10){
					l[20] = 1
				}
				else{
					l[20] = 0
				}
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[2] == "ev021"){
			if(k[3] == "measure"){
				l[20] = 1
			}
			elseif(k[3] == "cc"){
				if(l[1] > 10){
					l[20] = 1
				}
				else{
					l[20] = 0
				}
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev031_ango"){
			l[20] = 0
		}
		elseif(k[1] == "ev032_bus"){
			l[20] = 0
		}
		elseif(k[2] == "ev112"){
			if(k[3] == "first"){
				if(l[1] > 10){
					l[20] = 1
				}
				else{
					l[20] = 0
				}
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev122_chu"){
			if(l[1] >= 21 && l[1] <= 25){
				l[20] = 0
			}
			else{
				l[20] = 1
			}
		}
		elseif(k[1] == "ev142_cc"){
			if(l[1] > 10){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev213_pool"){
			if(l[1] > 10){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev217_bloom"){
			if(l[1] == 0){
				l[20] = 0
			}
			else{
				l[20] = 1
			}
		}
		elseif(k[1] == "ev218_bus"){
			if(l[1] > 20){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[2] == "ev219"){
			l[20] = 0
		}
		elseif(k[1] == "ev222_fella"){
			if(l[1] == 0 || l[1] >= 51){
				l[20] = 0
			}
			else{
				l[20] = 1
			}
		}
		elseif(k[1] == "ev226_merry"){
			if(l[1] >= 21){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev227_lap"){
			l[20] = 0
		}
		elseif(k[1] == "ev229_care"){
			l[20] = 0
		}
		elseif(k[2] == "ev232"){
			if(k[3] == "game"){
				if(l[1] >= 11){
					l[20] = 1
				}
				else{
					l[20] = 0
				}
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev236_bus"){
			if(l[1] >= 11){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev237_teeth"){
			if(l[1] >= 31){
				l[20] = 0
			}
			else{
				l[20] = 1
			}
		}
		elseif(k[1] == "ev238_eiga"){
			if(l[1] >= 31){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev239_bonbon"){
			l[20] = 0
		}
		elseif(k[1] == "ev242_research"){
			if(l[1] >= 21){
				l[20] = 1
			}
			else{
				l[20] = 0
			}
		}
		elseif(k[1] == "ev249_milk"){
			l[20] = 0
		}
		else{
			l[20] = 1
		}
	}
	elseif(k[0] == "st226_merry_bg"){
		if(front.object[@obj_no_bg].child[1].child[0].get_file_name == "st226_merry_21_cut"){
			l[20] = 1
		}
		elseif(front.object[@obj_no_bg].child[1].child[0].get_file_name == "st226_merry_31_cut"){
			l[20] = 1
		}
	}
	else{
		l[20] = 0
	}



// �܂��A�����G���S���E�p���c�E�̏ꍇ�s����
	for(l[10] = 0, l[10] < 4, l[10] += 1){
		if(front.object[@obj_no_bs + l[10]].child.get_size > 0){
			if($bs_inf[@bs_inf_dress + l[10] * @bs_inf_count].left(2) == "na"){
				l[20] = 1
			}
			elseif($bs_inf[@bs_inf_dress + l[10] * @bs_inf_count].left(3) == "pnt"){
				l[20] = 1
			}
			elseif($bs_inf[@bs_inf_dress + l[10] * @bs_inf_count].left(3) == "pjc"){
				l[20] = 1
			}
		}
	}

// ���̌��ʂ��ȉ��ɂ���
	//front.object[49].create(siro,l[20])
	@tweet_limit = l[20]
}

