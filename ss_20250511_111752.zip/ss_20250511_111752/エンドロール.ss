// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		�G���f�B���O
//		
//			�N���W�b�g���X
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
#inc_start

#define		@obj_bg		0
#define		@obj_roll	2
#define		@obj_foot	4
#define		@obj_frame	6

#property	$skip_end


#inc_end

command $restrict{
	koe_stop
	close

	script.set_ctrl_skip_enable// Ctrl�L�[�̃X�L�b�v�͐������Ȃ�
	script.set_skip_disable
	script.set_mouse_disp_off
	syscom.set_syscom_menu_disable
	script.set_msg_back_disable
	
}

command $lift{

	script.set_mouse_disp_on
	script.set_ctrl_skip_enable
	script.set_skip_enable
	syscom.set_syscom_menu_disable
	script.set_msg_back_enable

}

command $obj_set{

	// �w�i
	back.object[@obj_bg].create(_end_bg, 1, 0, 0, 0)
	
	// �X�^�b�t���[��
	back.object[@obj_roll].init
	back.object[@obj_roll].disp = 1
	back.object[@obj_roll].set_pos(652, 720)
	back.object[@obj_roll].child.resize(5)
	for(l[0] = 0, l[0] < 5, l[0] += 1){
		back.object[@obj_roll].child[l[0]].create(_end_roll, 1, 0, 2000 * l[0], l[0])
	}
	
	// �t�b�^�[
	back.object[@obj_foot].create(_end_foot, 1, 0, 0)
	
	// �X�e�[�W
	back.object[@obj_frame].init
	back.object[@obj_frame].disp = 1
	back.object[@obj_frame].child.resize(5)
	back.object[@obj_frame].set_pos(16, 89)
	
	// ����
	back.object[@obj_frame].child[0].create(_end_stage, 1, 0, 0, 0)
	

	// �d��̃L����
	back.object[@obj_frame].child[1].create(_end_chara, 1, 450+50, 47+230, @fixed_route)

	// ��
	back.object[@obj_frame].child[2].create(_end_note, 1, 313, 42, 0)
	
	// ���Ă���L����
	back.object[@obj_frame].child[3].disp = 1
	back.object[@obj_frame].child[3].set_pos(55, 193)
	back.object[@obj_frame].child[3].child.resize(3)
	
	l[10] = 0
	l[11] = 0
	l[12] = 0
	l[13] = 0
	
	l[14] = 16
	if(@fixed_route != 0){
		back.object[@obj_frame].child[3].child[l[10]].create(_end_behind, 1, 0, 0, 0)
		l[10] += 1
		l[11] = 1
	}
	if(@fixed_route != 1){
		back.object[@obj_frame].child[3].child[l[10]].create(_end_behind, 1, l[14] * l[10] + 133 * l[11], 0, 1)
		l[10] += 1
		l[12] = 1
	}
	if(@fixed_route != 2){
		back.object[@obj_frame].child[3].child[l[10]].create(_end_behind, 1, l[14] * l[10] + 133 * l[11] + 150 * l[12], 0, 2)
		l[10] += 1
		l[13] = 1
	}
	if(@fixed_route != 3){
		back.object[@obj_frame].child[3].child[l[10]].create(_end_behind, 1, l[14] * l[10] + 133 * l[11] + 150 * l[12] + 116 * l[13], 0, 3)
	}
	
	
	
	// �g
	back.object[@obj_frame].child[4].create(_end_frame, 1, 0, 0, 0)
	
	
	
	wipe

}

command $obj_start{
	//ctrl skip�o����͎̂d�l
	front.object[@obj_roll].frame_action.start(-1, "$staff_roll")
//	front.object[@obj_house].frame_action.start_real(-1, "$end_scroll")
//	front.object[@obj_usamin].frame_action.start(-1, "$usamin_walk")
//	front.object[@obj_staff].frame_action.start_real(-1, "$staff_roll")
	
}

command $staff_roll(property $fa:frameaction, property $obj:object){

	l[0] = $fa.counter.get 
	
	l[1] = math.timetable(l[0], 0, 720, [0, 153000, -8415, 0])
	
	$obj.y = l[1]
}

command $kouka(property $ch){

	k[0] = "ed" + math.tostr($ch)
	bgm.play_oneshot(k[0])

}



#z00
//@prefer_decision = 1
$restrict
$obj_set
$kouka(@fixed_route)//bgm.play_oneshot(kouka)
$obj_start

while(1){

	// �d�c���΂Ηl�����������Ԍo�߁����D���l���ɂ͂Ȃ�Ȃ�
	$mama_key_check

	if(bgm.check == 0){
		break
	}
	if(input.decide.on_down == 1 || input.cancel.on_down == 1){
		if(@�N���A���� == 1 || front.object[@obj_roll].y == -8415){
			break
		}
	}

	input.next
	disp
}

wipe_all

$lift

return
