// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		�Z�[�u���j���[
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
/*
�O�`�X�X�F�ʏ�Z�[�u
�P�O�O�`�P�O�X�F�I�[�g�Z�[�u�i�N�C�b�N�Z�[�u�̗̈�j
�P�P�O�`�P�P�X�F�N�C�b�N�Z�[�u
�N�C�b�N�Z�[�u�͔ԍ����w�肵�ĉ]�X

�{�^���̃A�N�V�����ɘA���A�����ʉ��ɉe�����o�Ȃ����߂̏����T��

*/
// ==========================================================
// ��`
// ----------------------------------------------------------
#inc_start



	//�{�^���A����т��̕␳�l
	#define		@btn_cancel			-1
	
	#define		@btn_menu_start		000
	#define		@btn_menu_system	000
	#define		@btn_menu_txt		001
	#define		@btn_menu_sound		002
	#define		@btn_menu_mama		003
	
	#define		@btn_sc_start		004
	#define		@btn_sc_quit		004
	#define		@btn_sc_title		005
	#define		@btn_sc_save		006
	#define		@btn_sc_load		007
	#define		@btn_sc_config		008
	#define		@btn_sc_return		009

	#define		@btn_save			10
	#define		@btn_page			20
	#define		@btn_del			40

	// �I�u�W�F�N�g�ԍ�
	#define		@obj_base			0
	#define		@obj_above_menu			001
	#define		@obj_below_menu			002
//	#define		@obj_sc				10
	
	#define		@obj_save_bg		20
	#define		@obj_save			30
	#define		@obj_page_bg		40
	#define		@obj_page			41





	// �ݒ�l�֘A
	#define		@save_cnt			10

	#define		@pos_x				113
	#define		@pos_y				160
	#define		@pos_x_rev			498
	#define		@pos_y_rev			88


#macro		@get_save_info(@save_no, @year, @month, @day, @weekday, @hour, @minute, @second, @millisecond)
				@year = syscom.get_save_year(@save_no)
				@month = syscom.get_save_month(@save_no)
				@day = syscom.get_save_day(@save_no)
				@weekday = syscom.get_save_weekday(@save_no)
				@hour = syscom.get_save_hour(@save_no)
				@minute = syscom.get_save_minute(@save_no)
				@second = syscom.get_save_second(@save_no)
				@millisecond = syscom.get_save_millisecond(@save_no)

#inc_end

// ==========================================================
// �E�B���h�E�{�^���Ȃǂ���Ăяo���ꍇ�͂���
// ----------------------------------------------------------
// �Ăяo�����ꍇ�͂���������
#z00

	$excall_ready		// �V�X�e���R�[��������
	gosub #z01			// �{�̂�
	$excall_wipe		// ���C�v���ďI��
	$excall_free		// �V�X�e���R�[�������
	return				// �V�X�e���R�[�����甲����

// *************************************************************
// �Z�[�u���j���[
// =============================================================
//		���̂d�w�R�[������Ăяo���ꍇ�͂������Ăяo���܂��B
// =============================================================
#z01

	// ������
	gosub #init

	// ���C�v
	$excall_wipe

	// �{�^���O���[�v�I���J�n
	excall.front.objbtngroup[0].start_cancel

	// �I���J�n
	input.clear
	while(1){

		// ���肳�ꂽ�{�^���̎擾
		l[2] = excall.front.objbtngroup[0].get_decided_no

		// 
		$mama_key_check

		// �{�^���̌��菈��

		// �y�[�W�{�^��
		if(@btn_page <= l[2] && l[2] < @btn_page + 20){
			@save_last_page = l[2] - @btn_page
			$update_obj_page(1)
			$update_obj_save_colony(1)
			$update_obj_save_new(1)
		}

		// �Z�[�u�{�^��
		if(@btn_save <= l[2] && l[2] < @btn_save + 10){
			// �Z�[�u�f�[�^������ꍇ
			if(syscom.get_save_exist(@save_last_page * 10 + l[2] - @btn_save)){
				// �㏑���m�F����ꍇ
				if(@confirm_overwrite){
					if(farcall(_att_msg, 01, 1) == 1){
						syscom.save(@save_last_page * 10 + l[2] - @btn_save, 0, 0)
						syscom.set_save_value(@save_last_page * 10 + l[2] - @btn_save, a, 11, 4)
						$update_obj_save(1, l[2] - @btn_save)
						$update_obj_save_new(1)
					}
				}
				else{
					syscom.save(@save_last_page * 10 + l[2] - @btn_save, 0, 0)
					syscom.set_save_value(@save_last_page * 10 + l[2] - @btn_save, a, 11, 4)
					$update_obj_save(1, l[2] - @btn_save)
					$update_obj_save_new(1)
				}
			}
			else{
				syscom.save(@save_last_page * 10 + l[2] - @btn_save, 0, 0)
				syscom.set_save_value(@save_last_page * 10 + l[2] - @btn_save, a, 11, 4)
				$update_obj_save(1, l[2] - @btn_save)
				$update_obj_save_new(1)
			}
/*
			// �Z�[�u�f�[�^������ꍇ
			if(syscom.get_save_exist(@save_last_page * 10 + l[2] - @btn_save)){
				// �Ǎ��m�F
				if(@confirm_load){
					l[0] = farcall(_att_msg, 01, 0)
				}
				if(l[0] != -1){
					syscom.load(@save_last_page * 10 + l[2] - @btn_save, 0, 1, 1)
				}
			}
*/
		}

		// �폜�{�^��
		if(@btn_del <= l[2] && l[2] < @btn_del + 10){
			// �폜�m�F����ꍇ
			if(@confirm_del){
				l[0] = farcall(_att_msg, 01, 4)
				if(l[0] == 1){
					syscom.delete_save(@save_last_page * 10  + l[2] - @btn_del)
					$update_obj_save(1, l[2] - @btn_del)
					$update_obj_save_new(1)
				}
			}
			else{
				syscom.delete_save(@save_last_page * 10  + l[2] - @btn_del)
				$update_obj_save(1, l[2] - @btn_del)
				$update_obj_save_new(1)
			}
		}

		// ��Ӄ��j���[
		if(l[2] == @btn_menu_system){
			@config_last_page = 0
			jump(_config, 01)//syscom.call_config_menu
		}
		if(l[2] == @btn_menu_txt){
			@config_last_page = 1
			jump(_config, 01)//syscom.call_config_menu
		}
		if(l[2] == @btn_menu_sound){
			@config_last_page = 2
			jump(_config, 01)//syscom.call_config_menu
		}
		if(l[2] == @btn_menu_mama){
			@config_last_page = 3
			jump(_config, 01)
		}
		
		// ���ӃV���[�g�J�b�g
		if(l[2] == @btn_sc_quit){
			$end_game(1)
		}
		if(l[2] == @btn_sc_title){
			$return_title(1)
		}
		if(l[2] == @btn_sc_save){
			jump(_save, 01)//syscom.call_save_menu//jump(_save, 01)
		}
		if(l[2] == @btn_sc_load){
			jump(_load, 01)//syscom.call_load_menu//jump(_load, 01)
		}
		if(l[2] == @btn_sc_config){
			jump(_config, 01)//syscom.call_config_menu
		}
		
		// �L�����Z��
		if(l[2] == @btn_cancel || l[2] == @btn_sc_return){
			break
		}

		// �z�C�[������ɉ񂵂��ꍇ
		if(mouse.wheel < 0){
			@save_last_page -= 1
			if(@save_last_page < 0){
				@save_last_page = 11
			}
			$update_obj_page(1)
			$update_obj_save_colony(1)
			$update_obj_save_new(1)
		}
		// �z�C�[�������ɉ񂵂��ꍇ
		if(mouse.wheel > 0){
			@save_last_page += 1
			if(@save_last_page > 11){
				@save_last_page = 0
			}
			$update_obj_page(1)
			$update_obj_save_colony(1)
			$update_obj_save_new(1)
		}


		// �I���ĊJ����
		if(l[2] >= 0){
			excall.front.objbtngroup[0].init
			excall.front.objbtngroup[0].start_cancel
		}

		input.next
		disp

	}

	return


// ==========================================================
// ������
// ----------------------------------------------------------
#init


	// �{�^���O���[�v�̏�����
	excall.back.objbtngroup[0].init

	// �ȉ��A�I�u�W�F�N�g�̏���

	// �y��
	excall.back.object[@obj_base].create(_config_bg_filter, 1)
	excall.back.object[@obj_base].child.resize(3)
	excall.back.object[@obj_base].child[0].create(_config_base_bg, 1, 0, 90)
//	excall.back.object[@obj_base].child[0].color_add_b = 16
	excall.back.object[@obj_base].child[1].create(_save_title_logo, 1, 13, 103, 0)
	excall.back.object[@obj_base].child[2].create(_save_bg_blue, 1, 70, 114)
	excall.back.object[@obj_base].child[2].color_add_b = 16
	// �y�[�W�ԍ�
	excall.back.object[@obj_page_bg].init
	excall.back.object[@obj_page_bg].set_pos(683+2, 122+2)
	excall.back.object[@obj_page_bg].disp = 1
	excall.back.object[@obj_page_bg].child.resize(12)
	
	excall.back.object[@obj_page].init
	excall.back.object[@obj_page].set_pos(683, 122)
	excall.back.object[@obj_page].disp = 1
	excall.back.object[@obj_page].child.resize(12)

	// �y�[�W�ԍ��̍��W�␳�l
	l[10] = 36
	
	for(l[0] = 0, l[0] < 12, l[0] += 1){
		if(l[0] >= 10){ l[11] = 6 }
		excall.back.object[@obj_page_bg].child[l[0]].create(_save_btn_page, 1, l[10] * l[0] + l[11], 0, 24)
	}

	l[11] = 0
	for(l[0] = 0, l[0] < 12, l[0] += 1){
		if(l[0] >= 10){ l[11] = 6 }
		excall.back.object[@obj_page].child[l[0]].create(_save_btn_page, 1, l[10] * l[0] + l[11], 0, l[0] * 2)
	}

	excall.back.object[@obj_save_bg].init
	excall.back.object[@obj_save_bg].set_pos(@pos_x + 2, @pos_y + 2)
	excall.back.object[@obj_save_bg].disp = 1
	excall.back.object[@obj_save_bg].child.resize(10)
	// �Z�[�u�f�[�^�̔w�i
	for(l[0] = 0, l[0] < 10, l[0] += 1){
		excall.back.object[@obj_save_bg].child[l[0]].create(_save_btn_base_bg, 1, l[0] / 5 * @pos_x_rev, l[0] % 5 * @pos_y_rev)
	}

	// �y�[�W�I��
	$update_obj_page(0)

	// �Z�[�u�{�^���Q
	$update_obj_save_colony(0)

	// �m����
	$update_obj_save_new(0)
	
	$above_menu_disp(0)
	$below_menu_disp(0)

/*
	// �Z�[�u��
	if(@���j���[�� == 1){
		excall.back.object[@obj_sc + 2].set_button_state_disable
	}
*/


	return


// ==========================================================
// �y�[�W���j���[�F�y�[�W�I�u�W�F�N�g�̍X�V
// ----------------------------------------------------------
command $update_obj_page(property $stage){

	for(l[0] = 0, l[0] < 12, l[0] += 1){

		excall.stage[$stage].object[@obj_page].child[l[0]].set_button(l[0] + @btn_page, 0, 2, 0)
		excall.stage[$stage].object[@obj_page].child[l[0]].patno = l[0] * 2

		if(l[0] == @save_last_page){
			excall.stage[$stage].object[@obj_page].child[l[0]].clear_button
			excall.stage[$stage].object[@obj_page].child[l[0]].patno += 1
		}

	}

}



// ==========================================================
// �Z�[�u���j���[�F�Z�[�u�I�u�W�F�N�g�̍X�V
// ----------------------------------------------------------
// �Q��
command $update_obj_save_colony(property $stage_no)
{

	for(l[0] = 0, l[0] < 10, l[0] += 1){
		$update_obj_save($stage_no, l[0])
	}
}

// �P��
command $update_obj_save(property $stage_no, property $no){

	// �y��
	excall.stage[$stage_no].object[@obj_save + $no].create(_save_btn_base, 1, @pos_x + $no / 5 * @pos_x_rev, @pos_y + $no % 5 * @pos_y_rev)
	excall.stage[$stage_no].object[@obj_save + $no].set_button(@btn_save + $no, 0, 2, 0)
	excall.stage[$stage_no].object[@obj_save + $no].child.resize(7)
	// �ԍ�
	excall.stage[$stage_no].object[@obj_save + $no].child[0].create_number(_save_btn_num, 1, 3, 49)
	excall.stage[$stage_no].object[@obj_save + $no].child[0].set_number_param(3, 1, 0, 0, 0, 0)
	excall.stage[$stage_no].object[@obj_save + $no].child[0].set_number(@save_last_page * 10 + $no)
	excall.stage[$stage_no].object[@obj_save + $no].child[0].set_button(@btn_save + $no, 0, 2, 0)
	// �S�~��
	excall.stage[$stage_no].object[@obj_save + $no].child[1].create(_save_btn_del, 1, 400, 39)
	excall.stage[$stage_no].object[@obj_save + $no].child[1].set_button(@btn_del + $no, 0, 7, 0)


	// �Z�[�u�f�[�^������ꍇ
	if(syscom.get_save_exist(@save_last_page * 10 + $no)){
		// �S�~���̃{�^����
//		excall.stage[$stage_no].object[@obj_save + $no].child[1].set_button(@btn_del + $no, 0, 7, 0)
		// �Z�[�u�T���l�C��
		// �Z�[�u�T���l�C�����Ȃ��ꍇ�̏����B�ł��Ȃ�
		excall.stage[$stage_no].object[@obj_save + $no].child[2].create_save_thumb(@save_last_page * 10 + $no, 1, 55, 4)
		excall.stage[$stage_no].object[@obj_save + $no].child[2].set_button(@btn_save + $no, 0, 2, 0)
		// �Z�[�u����
		excall.stage[$stage_no].object[@obj_save + $no].child[3].create_string($get_save_time(@save_last_page * 10 + $no), 1, 182, 6)
		excall.stage[$stage_no].object[@obj_save + $no].child[3].set_string_param(14, 1, 0, 23, 100, 1, 0)
		excall.stage[$stage_no].object[@obj_save + $no].child[3].set_button(@btn_save + $no, 0, 2, 0)
		// �Z�[�u�^�C�g��
		k[0] = "��" + syscom.get_save_title(@save_last_page * 10 + $no)
		excall.stage[$stage_no].object[@obj_save + $no].child[4].create_string(k[0].left(13), 1, 182, 30)
		excall.stage[$stage_no].object[@obj_save + $no].child[4].set_string_param(17, 0, 0, 20, 100, 1, 0)
		excall.stage[$stage_no].object[@obj_save + $no].child[4].set_button(@btn_save + $no, 0, 2, 0)
		// �Z�[�u���b�Z�[�W
		k[1] = syscom.get_save_message(@save_last_page * 10 + $no)
		if((syscom.get_save_title(@save_last_page * 10 + $no) == @option_first) || (syscom.get_save_title(@save_last_page * 10 + $no) == @option_second) || (syscom.get_save_title(@save_last_page * 10 + $no) == @option_third) || (syscom.get_save_title(@save_last_page * 10 + $no) == @option_fourth) || (syscom.get_save_title(@save_last_page * 10 + $no) == @option_fifth)){
			syscom.get_save_value(@save_last_page * 10 + $no, l, 10, 4)
			k[1] = "�m�m�F" + math.tostr(l[10]) + "�����@�ڗ����F" + math.tostr(l[11]) + "����#D�z�@�F" + math.tostr(l[12]) + "�����@�݂邭�@�F" + math.tostr(l[13]) + "����"
		}
		elseif((syscom.get_save_title(@save_last_page * 10 + $no) == @title_1stday) || (syscom.get_save_title(@save_last_page * 10 + $no) == @title_2ndday) || (syscom.get_save_title(@save_last_page * 10 + $no) == @title_3rdday) || (syscom.get_save_title(@save_last_page * 10 + $no) == @title_fewday)){
			syscom.get_save_value(@save_last_page * 10 + $no, l, 10, 5)
			if(l[14] > 0){
				k[1] = "�m�m�F" + math.tostr(l[10]) + "�����@�ڗ����F" + math.tostr(l[11]) + "����#D�z�@�F" + math.tostr(l[12]) + "�����@�݂邭�@�F" + math.tostr(l[13]) + "����"
			}
		}
		excall.stage[$stage_no].object[@obj_save + $no].child[5].create_string(k[1].left(34), 1, 182, 51)
		excall.stage[$stage_no].object[@obj_save + $no].child[5].set_string_param(12, 0, 0, 17, 100, 1, 0)
		excall.stage[$stage_no].object[@obj_save + $no].child[5].set_button(@btn_save + $no, 0, 2, 0)
	}
	else{	// �Z�[�u�f�[�^���Ȃ��ꍇ�A�I�u�W�F�N�g�����{��{�^����
//		excall.stage[$stage_no].object[@obj_save + $no].dark = 48
		excall.stage[$stage_no].object[@obj_save + $no].child[1].set_button_state_disable
		excall.stage[$stage_no].object[@obj_save + $no].child[2].init
		excall.stage[$stage_no].object[@obj_save + $no].child[3].init
		excall.stage[$stage_no].object[@obj_save + $no].child[4].init
		excall.stage[$stage_no].object[@obj_save + $no].child[5].init
	}
//	excall.stage[$stage_no].object[@obj_save + $no].color_add_r = -8

	if(@save_last_page == 10 || @save_last_page == 11){
		excall.stage[$stage_no].object[@obj_save + $no].set_button_state_disable
		excall.stage[$stage_no].object[@obj_save + $no].child[1].set_button_state_disable
		
		excall.stage[$stage_no].object[@obj_save + $no].child[1].disp = 0
	}

}

// �m����
command $update_obj_save_new(property $stage_no){

	for(l[0] = 0, l[0] < 10, l[0] += 1){

		if (syscom.get_save_new_no == @save_last_page * 10 + l[0]
		|| (@save_last_page == 10 && @auto_save_no == l[0] && syscom.get_quick_save_exist(l[0]))
		|| (@save_last_page == 11 && @quick_save_no == l[0] && syscom.get_quick_save_exist(l[0] + 10))){
			excall.stage[$stage_no].object[@obj_save + l[0]].child[6].create(_save_btn_new, 1, -13, -7)
		}
		else{
			excall.stage[$stage_no].object[@obj_save + l[0]].child[6].free
		}
	}
}



// ==========================================================
// �Z�[�u���j���[�F�Z�[�u�����̕�����̎擾
// ----------------------------------------------------------
command $get_save_time(property $save_no) : str
{

	if(syscom.get_save_exist($save_no)){
		@get_save_info($save_no, l[20], l[21], l[22], l[23], l[24], l[25], l[26], l[27])
		k[0] += math.tostr_zero(l[20], 4) + "/" + math.tostr_zero(l[21], 2) + "/" + math.tostr_zero(l[22], 2)
		k[0] += "(" + $get_weekday_str(l[23]) + ")"
		k[0] += math.tostr_zero(l[24], 2) + ":" + math.tostr_zero(l[25], 2) + ":" + math.tostr_zero(l[26], 2) + ":" + math.tostr_zero(l[27], 3)
	}

	return(k[0])

}

// ==========================================================
// �Z�[�u���j���[�F�j���𕶎���ɕϊ�
// ----------------------------------------------------------
command $get_weekday_str(property $weekday) : str
{

	switch($weekday){
		case(0)	return("Sun")
		case(1)	return("Mon")
		case(2)	return("Tue")
		case(3)	return("Wed")
		case(4)	return("Thu")
		case(5)	return("Fri")
		case(6)	return("Sat")
	}
}

// ==========================================================
// ���L�p�[�c
// ----------------------------------------------------------
command $above_menu_disp(property $i){

	excall.stage[$i].object[@obj_above_menu].init
	excall.stage[$i].object[@obj_above_menu].disp = 1
	excall.stage[$i].object[@obj_above_menu].set_pos(684, 55)
	excall.stage[$i].object[@obj_above_menu].child.resize(4)
	
	for(l[0] = 0, l[0] < 4, l[0] += 1){
		excall.stage[$i].object[@obj_above_menu].child[l[0]].create(_config_btn_config_menu, 1, 113 * l[0], 0, 2 * l[0])
		excall.stage[$i].object[@obj_above_menu].child[l[0]].set_button(@btn_menu_start + l[0], 0, 2, 0)
	}
	
}

command $below_menu_disp(property $i){

	excall.stage[$i].object[@obj_below_menu].init
	excall.stage[$i].object[@obj_below_menu].disp = 1
	excall.stage[$i].object[@obj_below_menu].set_pos(458, 650)
	excall.stage[$i].object[@obj_below_menu].child.resize(6)

	for(l[0] = 0, l[0] < 6, l[0] += 1){
		excall.stage[$i].object[@obj_below_menu].child[l[0]].create(_config_btn_sc_menu, 1, 113 * l[0], 0, l[0] * 2)
		excall.stage[$i].object[@obj_below_menu].child[l[0]].set_button(@btn_sc_start + l[0], 0, 2, 0)
	}
	if(@��z��){
		excall.stage[$i].object[@obj_below_menu].child[1].patno = 12
	}
	excall.stage[$i].object[@obj_below_menu].child[2].patno += 1
	// �Z�[�u��
	if(@���j���[��){
		excall.stage[$i].object[@obj_below_menu].child[2].set_button_state_disable
	}
	if(@��z��){
		excall.stage[$i].object[@obj_below_menu].child[3].set_button_state_disable
	}
	
	// ��A�N�e�B�u
	excall.stage[$i].object[@obj_below_menu].child[2].set_button_state_disable
	
}

