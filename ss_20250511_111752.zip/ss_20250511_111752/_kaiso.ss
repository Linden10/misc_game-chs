// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		��z�V�[��
//		
//		
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

#inc_start

	// ���ڐ�
	#define		@cg_items		98
	#define		@cg_items_add	1		// �ʘg
	#define		@sc_items		62
	#define		@sc_items_add	0		// ed
	#define		@ed_items		4
	
	// �I�u�W�F�N�g�Ȃ�΁[
	#define		@obj_bg			0
	#define		@obj_frame		1
	#define		@obj_close		2
	#define		@obj_up			3
	#define		@obj_down		4
	#define		@obj_slide		5
	#define		@obj_mode		6
	#define		@obj_modify		7
	
	#define		@obj_star		8
	
	#define		@obj_rate		10
	#define		@obj_th			11
	
	
	// �ڂ���Ȃ�΁[
	#define		@btn_close		-1
	#define		@btn_up			0
	#define		@btn_down		1
	#define		@btn_slide		2
	#define		@btn_modify		3
	
	#define		@btn_cg_start	100
	#define		@btn_sc_start	300
	#define		@btn_ed_start	400
	
	#define		@btn_cg_eye		600
	
	// ���W
	#define		@th_pos_x		130
	#define		@th_pos_y		158
	#define		@clip_left		120
	#define		@clip_top		158
	#define		@clip_right		1000
	#define		@clip_bottom	632
	
	#define		@space_wid		150
	#define		@space_ver		100
	
	#define		@rail_pos_y		100
	#define		@rail_region	463
	
	#property	$line					// �T���l�C���̍s��
	#property	$th_region
	#define		$th_pos			g[061]
	#property	$push_btn_no
	#property 	$push_mouse_y
	#property	$push_btn_y
	
//	@kaiso_slide_pos	g[061]
#inc_end



#z00
@bgm(asa)
set_title(�ӏ܃��j���[)
$kaiso_menu_disp

wipe

front.objbtngroup[0].init
front.objbtngroup[0].start_cancel

while(1){

//	$update_object(1)
	
	l[0] = front.objbtngroup[0].get_hit_no
	l[1] = front.objbtngroup[0].get_pushed_no
	l[2] = front.objbtngroup[0].get_decided_no

	if($push_btn_no != l[1]){
		$push_btn_no = l[1]
		$push_mouse_y = mouse.pos_y
		
		if(l[1] == @btn_slide){
			$push_btn_y = front.object[@obj_slide].y
		}
	}
	
	if(l[1] == @btn_slide){
		$object_move(@obj_slide)
	}
	
	// �X�N���[���֘A
	// �A�b�v�{�^��
	if(l[2] == @btn_down){
		$th_pos -= @space_ver
		if($th_pos < - $th_region){
			$th_pos = - $th_region
		}
		$update_object(1)
	}
	if(l[2] == @btn_up){
		$th_pos += @space_ver
		if($th_pos > 0){
			$th_pos = 0
		}
		$update_object(1)
	}
	
	// �}�E�X
	if(mouse.wheel > 0){
		$th_pos -= @space_ver
		if($th_pos < - $th_region){
			$th_pos = - $th_region
		}
		$update_object(1)
	}
	if(mouse.wheel < 0){
		$th_pos += @space_ver
		if($th_pos > 0){
			$th_pos = 0
		}
		$update_object(1)
	}
	
	if(l[0] == @btn_modify){
		front.object[@obj_modify].patno = 0
		front.object[@obj_modify + 1].patno = 2
	}
	if(l[0] != @btn_modify){
		front.object[@obj_modify].patno = 1 - @kaiso_mode
		front.object[@obj_modify + 1].patno = 2 + @kaiso_mode
	}
	if(l[1] == @btn_modify){
		front.object[@obj_modify].patno = 0
		front.object[@obj_modify + 1].patno = 2
	}
	// ���[�h�̕ύX
	if(l[2] == @btn_modify){
		@kaiso_mode = 1 - @kaiso_mode
		front.object[@obj_mode].patno = @kaiso_mode
		
		front.object[@obj_modify].patno = 1 - @kaiso_mode
		front.object[@obj_modify + 1].patno = 2 + @kaiso_mode
		
		front.object[@obj_modify].set_button(@btn_modify, 0, 0, 0)
		front.object[@obj_modify + 1].set_button(@btn_modify, 0, 0, 0)
		front.object[@obj_modify + @kaiso_mode].clear_button
		$th_pos = 0
		$diverge(1)
		$update_object(1)
	}
	
	
	// �b�f�̃{�^���������ꂽ�ꍇ
	if(@btn_cg_start <= l[2] && l[2] < @btn_cg_start + @cg_items + @cg_items_add){
		l[1] = l[2] - @btn_cg_start
		k[0] = $cg_name(l[1])
		$pre_cg(k[0], 99)
		$kaiso_menu_disp
		wipe
	}
	
	if(@btn_cg_eye == l[2]){
		$pre_cg2(st000_eyecatch, 99)
		$kaiso_menu_disp
		wipe
	}
	
	// �V�[���̃{�^���������ꂽ�ꍇ
	if(@btn_sc_start <= l[2] && l[2] < @btn_sc_start + @sc_items){
		l[10] = l[2] - @btn_sc_start
		$replay(l[10])
	}
	
	// �G���h���[����
	if(@btn_ed_start <= l[2] && l[2] < @btn_ed_start + @ed_items){
		l[10] = l[2] - @btn_ed_start
		$replay_ed(l[10])
	}
	
	
	if(l[2] == @btn_close){
		break
	}
	
	if(l[2] >= 0){
		front.objbtngroup[0].init
		front.objbtngroup[0].start_cancel
	}
	disp
	f[0] += 1
}

return




// =========================================================
// ��z���j���[
// ---------------------------------------------------------
command $kaiso_menu_disp{

	// �w�i
	back.object[@obj_bg].init
	back.object[@obj_bg].disp = 1
	back.object[@obj_bg].child.resize(4)
	back.object[@obj_bg].child[0].create(bgi09, 1, 1152/2, 720/2)
	back.object[@obj_bg].child[1].create(_config_bg_filter, 1)//_rect(0,0, 1152,729, 58,55,88, 74, 1)
	back.object[@obj_bg].child[2].create(_msgbk_filter, 1)
	
	// ������
//	back.object[@obj_star].create(_kaiso_star, 1, 48, 71)
	
	// ���[�h�\��
	back.object[@obj_mode].create(_kaiso_mode, 1, 48, 71, @kaiso_mode)
	
	// ����A�߂�{�^��
	back.object[@obj_close].create(_msgbk_btn_close, 1, 1087, 640)
	back.object[@obj_close].set_button(@btn_close, 0, 2, 0)
	
	// ��
	back.object[@obj_up].create(_msgbk_btn_up, 1, 1094, 75)
	back.object[@obj_up].set_button(@btn_up, 0, 2, 0)
	
	// ��
	back.object[@obj_down].create(_msgbk_btn_down, 1, 1094, 612)
	back.object[@obj_down].set_button(@btn_down, 0, 2, 0)
	
	// �X���C�_�[
	back.object[@obj_slide].create(_msgbk_slide_cursor, 1, 1093, @rail_pos_y)
	back.object[@obj_slide].set_button(@btn_slide, 0, 6, 0)
	back.object[@obj_slide].set_button_pushkeep(1)
	
	// ���[�h�ύX
	back.object[@obj_modify].create(_kaiso_btn_modify, 1, 843, 72, 0)
	back.object[@obj_modify+1].create(_kaiso_btn_modify, 1, 843, 110, 2)
	back.object[@obj_modify + @kaiso_mode].patno += 1
	
	back.object[@obj_modify + 1 - @kaiso_mode].set_button(@btn_modify, 0, 0, 0)
	
	// ���[�h����
	$diverge(0)
	
	$update_object(0)
	
}

// =========================================================
// ���[�h
// ---------------------------------------------------------
command $diverge(property $i){

	if(@kaiso_mode == 0){
	
		l[0] = @cg_items + @cg_items_add// + @clear_ex_00 * 2 + @clear_ex_01 * 2 + @clear_ex_02 * 3 + @clear_ex_03
		
		$line = l[0] / 6
		if(l[0] % 6 > 0){ $line += 1 }
		
		$th_cg($i)
		
	}
	else{
	
		l[0] = @sc_items + @clear_nono + @clear_ruri + @clear_rin + @clear_milk
		
		$line = l[0] / 6
		if(l[0] % 6 > 0){ $line += 1 }
		
		$th_sc($i)
		
	}
	
	if($line < 6){
		$th_region = 0
	}
	else{
		$th_region = @space_ver * ($line - 5)
	}

}

// =========================================================
// �b�f
// ---------------------------------------------------------
command $th_cg(property $i){

	l[0] = cgtable.get_look_percent
	// �p�[�Z���g�\��
	stage[$i].object[@obj_rate].init
	stage[$i].object[@obj_rate].disp = 1
	stage[$i].object[@obj_rate].set_pos(610, 80)
	stage[$i].object[@obj_rate].child.resize(2)
	stage[$i].object[@obj_rate].child[0].create_number(_kaiso_num, 1)
	stage[$i].object[@obj_rate].child[0].set_number_param(3, 0, 0, 0, 0, 0)
	stage[$i].object[@obj_rate].child[0].set_number(l[0])
	stage[$i].object[@obj_rate].child[1].create(_kaiso_num, 1, 111, 0, 10)
	
	// �T���l�C��
	stage[$i].object[@obj_th].init
	stage[$i].object[@obj_th].disp = 1
	stage[$i].object[@obj_th].set_pos(@th_pos_x, @th_pos_y)
	stage[$i].object[@obj_th].set_clip(1, @clip_left, @clip_top, @clip_right, @clip_bottom)
	l[0] = @cg_items + @cg_items_add
	stage[$i].object[@obj_th].child.resize(l[0])
	
	for(l[0] = 0, l[0] < @cg_items, l[0] += 1){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		k[0] = $cg_name(l[0])
		if($cg_mita(k[0])){						// �b�f�������ꍇ
			k[0] = "th_" + k[0]					// �T���l�C���摜��
			stage[$i].object[@obj_th].child[l[0]].child[1].create(k[0], 1)
			stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_cg_start + l[0], 0, 2, 0)
		}
		else{
			stage[$i].object[@obj_th].child[l[0]].child[1].create(_kaiso_nodata, 1)
		}
	}
	
	if(@�N���A����){	// �A�C�L���b�`��
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		k[0] = $cg_name(l[0])
		k[0] = "th_" + k[0]					// �T���l�C���摜��
		stage[$i].object[@obj_th].child[l[0]].child[1].create(k[0], 1)
		stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_cg_eye, 0, 2, 0)
	}
}

// �b�f�t�@�C����
command $cg_name(property $i):str{

	k[0] = database[0].get_str($i, 0) + "_" + database[0].get_str($i, 1)
	
	return(k[0])
	
}


// �b�f�����H
command $cg_mita(property $s:str){

	for(l[0] = 0, l[0] < 99, l[0] += 1){
		k[0] = $s + "_" + math.tostr_zero(l[0], 2)
		if(cgtable.get_look_by_name(k[0]) == 1){
			return(1)
		}
	}
}

// �b�f��\�����鏀��
command $pre_cg(property $cg:str, property $i:int){

	for(l[0] = 0, l[0] < $i, l[0] += 1){
		k[0] = $cg + "_" + math.tostr_zero(l[0], 2)
		if($disp_cg(k[0]) == 0){
			return
		}
	}
}

command $pre_cg2(property $cg:str, property $i:int){
	
	for(l[0] = 0, l[0] < $i, l[0] += 1){
		k[0] = $cg + "_" + math.tostr_zero(l[0], 2)
		if($disp_cg2(k[0]) == 0){
			return
		}
	}
}

// �b�f��\������
command $disp_cg(property $cg:str){
	if(cgtable.get_look_by_name($cg) == 0 || cgtable.get_look_by_name($cg) == -1){
		return(1)
	}
	back.object[@obj_bg].create($cg, 1)
	wipe(time = 120)
	
	input.clear
	while(1){
		if(input.decide.on_down || mouse.wheel > 0){
			return(1)
		}
		if(input.cancel.on_down){
			return(0)
		}
		disp
	}
}

command $disp_cg2(property $cg:str){

	k[0] = "g00\\" + $cg + ".g00"
	if(system.check_file_exist(k[0]) != 1){
		return(1)
	}

	back.object[@obj_bg].create($cg, 1)
	wipe
	
	input.clear
	while(1){
		if(input.decide.on_down || mouse.wheel > 0){
			return(1)
		}
		if(input.cancel.on_down){
			return(0)
		}
		disp
	}
}


// =========================================================
// �V�[���ӏ�
// ---------------------------------------------------------
command $th_sc(property $i){

	stage[$i].object[@obj_rate].init
	
	stage[$i].object[@obj_th].init
	stage[$i].object[@obj_th].disp = 1
	stage[$i].object[@obj_th].set_pos(@th_pos_x, @th_pos_y)
	stage[$i].object[@obj_th].set_clip(1, @clip_left, @clip_top, @clip_right, @clip_bottom)
	l[0] = @sc_items + @sc_items_add + @ed_items
	stage[$i].object[@obj_th].child.resize(l[0])
	
	for(l[0] = 0, l[0] < @sc_items, l[0] += 1){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		l[10] = database[1].get_num(l[0], 0)//$sc_name(l[0])
		if(@kaiso(l[10]) == 1){
			k[0] = "th_" + database[1].get_str(l[0], 1)
			if(k[0] == "th_"){
			
			}
			else{
				stage[$i].object[@obj_th].child[l[0]].child[1].create(k[0], 1)
			}
			stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_sc_start + l[0], 0, 2, 0)
		}
		else{
			k[0] = "_kaiso_nodata"
			stage[$i].object[@obj_th].child[l[0]].child[1].create(k[0], 1)
		}
	}
	
	if(@clear_nono){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		stage[$i].object[@obj_th].child[l[0]].child[1].create(th_end, 1, 0, 0, 0)
		stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_ed_start, 0, 2, 0)
		
		l[0] += 1
	}
	if(@clear_ruri){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		stage[$i].object[@obj_th].child[l[0]].child[1].create(th_end, 1, 0, 0, 1)
		stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_ed_start + 1, 0, 2, 0)
		
		l[0] += 1
	}
	if(@clear_rin){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		stage[$i].object[@obj_th].child[l[0]].child[1].create(th_end, 1, 0, 0, 2)
		stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_ed_start + 2, 0, 2, 0)
		
		l[0] += 1
	}
	if(@clear_milk){
		stage[$i].object[@obj_th].child[l[0]].init
		stage[$i].object[@obj_th].child[l[0]].disp = 1
		stage[$i].object[@obj_th].child[l[0]].x = @space_wid * (l[0] % 6)
		stage[$i].object[@obj_th].child[l[0]].y = @space_ver * (l[0] / 6)
		stage[$i].object[@obj_th].child[l[0]].child.resize(2)
		stage[$i].object[@obj_th].child[l[0]].child[0].create_rect(0,0, 115,72, 54,32,32, 255, 1, 2, 2)
		stage[$i].object[@obj_th].child[l[0]].child[1].create(th_end, 1, 0, 0, 3)
		stage[$i].object[@obj_th].child[l[0]].child[1].set_button(@btn_ed_start + 3, 0, 2, 0)
		
		l[0] += 1
	}




	
	// @clear_milk
}

command $replay(property $i){

	bgm.stop(1000)
	syscom.set_save_enable_flag(0)
	syscom.set_load_enable_flag(0)
	$mwnd_btn_blind_view
	script.set_hide_mwnd_enable
	syscom.set_hide_mwnd_enable_flag(1)
	syscom.set_syscom_menu_enable
	script.set_msg_back_enable
	script.set_ctrl_skip_enable
	@kaiso_chu = 1
	// 0:flag_no 1:th_name
	k[0] = database[1].get_str($i, 2)	// ss file
	l[0] = database[1].get_num($i, 3)	// z label
	k[1] = database[1].get_str($i, 4)	// caption
	set_title(k[1])
	@bgv_no
	@bgv_ru
	@bgv_ri
	@bgv_mi
	$mwnd_btn_load = 1
	$mwnd_btn_watch(1)
	$mwnd_btn_blind_view
	farcall(k[0], l[0])
	
	returnmenu
}

command $replay_ed(property $i){
	@kaiso_chu = 1
	bgm.stop(1000)
	wipe(0, 1000)
	@fixed_route = $i
	farcall(�G���h���[��)
	
	returnmenu
}

command $update_object(property $i){

	stage[$i].object[@obj_th].y = $th_pos + @th_pos_y
	stage[$i].object[@obj_slide].y = math.timetable(- $th_pos, 0, @rail_pos_y, [0, $th_region, @rail_pos_y + @rail_region])
	
}

command $object_move(property $obj){

	front.object[$obj].y = $push_btn_y + mouse.pos_y - $push_mouse_y

	$th_pos =  - math.timetable(front.object[$obj].y, 0, 0, [@rail_pos_y, @rail_pos_y + @rail_region, $th_region])
	
	$update_object(1)

}
