// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		
//		
//		
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

#z00

$meter_stand(0)

frame_action_ch[@frame_action_ch_no_mama_key].start(-1, "$mama_watch")

//$meter_watch(@meter_load)

//���������p�̏������ǉ�
/*
if(@bgv_h_play != -1){
	$play_bgv(1, @bgv_h_play / 10, @bgv_h_play % 10)
}

if(@bgv_r_play != -1){
	$play_bgv(2, @bgv_r_play / 10, @bgv_r_play % 10)
}

if(@bgse_play != ""){
	$play_bgse(@bgse_play)
}

if(@bgse2_play != ""){
	$play_bgse2(@bgse2_play)
}
*/
//$mwnd_btn_blind_view
//$load_after_binde
return


command $load_after_binde{

	// �w�i�A�C�x���g�G
	if(front.object[@obj_no_bg].child.get_size != 0){
		front.object[@obj_no_bg].child[0].disp = @mekakushi
	}
	
	//bg->child[0] pr->child[9] st->child[9] ch->child[5]
	if(front.object[1].get_file_name == "_prefer_circle"){
		for(l[0] = 0, l[0] < 3, l[0] += 1){
			front.object[l[0] + 1].child[0].child[1].disp = @mekakushi
		}
		return
	}
	
	// �w�i�F���o�p
	if(front.object[@obj_no_st].child.get_size != 0){
		front.object[@obj_no_st].child[9].disp = @mekakushi
	}
	
	// �����G
	for(l[0] = 0, l[0] < 5, l[0] += 1){
		if(front.object[@obj_no_bs + l[0]].child.get_size != 0){
			front.object[@obj_no_bs + l[0]].child[5].disp = @mekakushi
		}
	}
	
	// usamin_onoff
	if(front.object[@obj_no_bg].get_file_name == "st023_usamin_onoff_bg"){
		front.object[@obj_no_bg].child[2].child[9].disp = @mekakushi
	}
	
	k[0] = front.object[@obj_no_cut].get_file_name
	if(k[0].left(10) == "evt30_bata" ||k[0] == "stt02_design_01"){
		front.object[@obj_no_cut].child[9].disp = @mekakushi
	}
	
	
	
	//��O������bg:st023_usamin_onoff_bg
	//front.object[1]..create(_prefer_circle)->child[0].child[1]
	
	

}
