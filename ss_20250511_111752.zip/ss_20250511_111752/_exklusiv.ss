// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		��`�F�I�u�W�F�N�g����̃R�}���h
// _/
//			���o�֌W���낢��
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

command $check_for_debug(property $fa:frameaction){

	for(l[0] = 0, l[0] < 3, l[0] += 1){
		f[l[0]] = syscom.get_global_extra_switch_onoff(l[0])
	}
	
	l[1] = $fa.counter.get % 2000 / 1000
//	front.object[@obj_no_bg].disp = l[1]
	

}

// ==========================================================
// �A�C�L���b�`
// ----------------------------------------------------------
command $eyecatch(property $i){

	script.set_msg_back_disable
	syscom.set_syscom_menu_disable
	l[40] = savepoint
	
	if(l[40] == 1){
		syscom.get_quick_save_value(@load_save_no, l, 41, 5)
		$card(l[45])	// 41/42/43/44/pt
	}
	else{
		l[45] = $card($i)
		l[46] = $auto_save
		if(l[46] == 1){
			for(l[0] = 0, l[0] < 4, l[0] += 1){
				l[41 + l[0]] = @prefer_start(l[0])
			}
			syscom.set_quick_save_value(@auto_save_no, l, 41, 5)
		}
	}
	script.set_msg_back_enable
	syscom.set_syscom_menu_enable
}

command $card(property $i){

	close
	koe_stop
	
	if($i == 0){
		$i = math.rand(1, 10)
	}
	
	l[0] = 1152/2 - 1152/10 * 3
	l[1] = 720/2 + 720/10 * 3
	
	switch($i){
		case(01)	k[0] = "st000_eyecatch_01"
		case(02)	k[0] = "st000_eyecatch_02"
		case(03)	k[0] = "st000_eyecatch_03"
		case(04)	k[0] = "st000_eyecatch_04"
		case(05)	k[0] = "st000_eyecatch_05"
		case(06)	k[0] = "st000_eyecatch_06"
		case(07)	k[0] = "st000_eyecatch_07"
		case(08)	k[0] = "st000_eyecatch_08"
		case(09)	k[0] = "st000_eyecatch_09"
		case(10)	k[0] = "st000_eyecatch_10"
	}
	
//	k[1] = "eveye_card_bb"
	l[3] = $i - 1

	l[10] = math.rand(1, 3)
	switch(l[10]){
		case(01)	l[11] = 5087
		case(02)	l[11] = 5099
		case(03)	l[11] = 4818
	}
	
	pcm.play("jingle_" + math.tostr(l[10]))
	
	front.object[@obj_no_bg].create(k[0], 1)
	front.object[@obj_no_bg].child.resize(1)
//	front.object[@obj_no_bg].child[0].create(k[1], @mekakushi, 0, 0, l[3])
	front.object[@obj_no_bg].center_rep_x = l[0]
	front.object[@obj_no_bg].center_rep_y = l[1]
	front.object[@obj_no_bg].frame_action.start(l[11] - 500, "$reduce")
	timewait_key(l[11] + 500)
	front.object[@obj_no_bg].frame_action.end
	pcm.stop

	return($i)
}

command $reduce(
	property $fa:frameaction,
	property $obj:object){

	l[0] = $fa.counter.get + 1
	l[1] = math.log10(l[0], 1000)
	$obj.scale_x = math.timetable(l[1], 0, 1500, [0, 3623, 1000])
	$obj.scale_y = math.timetable(l[1], 0, 1500, [0, 3623, 1000])
}


// ==========================================================
// ���L�I��
// ----------------------------------------------------------
command $day_start{

	l[40] = savepoint
	
	if(l[40]){
	
	}
	else{
		$auto_save
	}
}
// ����ڂ̏I���A�S�ďI��
command $day_end(property $str:str){

	clear
	close
	@pcm
//	@env
	@bgm
	@bgv_no
	@bgv_ru
	@bgv_ri
	@bgv_mi
	@bgse
	@ch_clear(0)
	@bgi($str, 11)
	$interlude(500)//timewait_key(@time_bg + 300)
	
}

command $op_playback{
	@pcm
		@bgi(kuro, 2)
close
	set_title(�I�[�v�j���O)
script.set_mouse_disp_off
	if(@�n�o���� == 0){
		mov.play_wait("op")
		@�n�o���� = 1
	}
	else{
		mov.play_wait_key("op")
	}
script.set_mouse_disp_on
	set_title(@title_1stday)
}

command $forced_outage{

	if(1){ return }
	
	if(@for_scripter && script.check_skip){
		while(1){
			if(input.decide.on_down == 1 || input.cancel.on_down == 1){
				break
			}
			input.next
			disp
		}
	}
	
}



command $msg_slow(property $i){

	if($i == 1){	// �ꎞ�I�ɒx������ꍇ
//		script.set_message_nowait_flag(0)
		l[0] = syscom.get_message_speed
		script.set_message_speed(l[0] + 100)
	}
	else{
//		script.set_message_nowait_flag(0)
		script.set_message_speed_default
	}
}


// �D���x���l�̔�r
command $route_confirmed{
	
	l[10] = @prefer_start(0)//@soine_no + @kyoi_no + @sugoroku_no + @ro_no + @tetsudai_no
	l[11] = @prefer_start(1)//@soine_ru + @kyoi_ru + @sugoroku_ru + @ro_ru + @tetsudai_ru
	l[12] = @prefer_start(2)//@soine_ri + @kyoi_ri + @sugoroku_ri + @ro_ri + @tetsudai_ri
	l[13] = @prefer_start(3)//@soine_mi + @kyoi_mi + @sugoroku_mi + @ro_mi + @tetsudai_mi
	
	// �N�����R�|�C���g�ȏ�Ȃ�m��
	for(l[0] = 0, l[0] < 4, l[0] += 1){
		if(l[10 + l[0]] > 2){
			@fixed_route = l[0]
			@route_established = 1
			return
		}
		elseif(l[10 + l[0]] == 2){	// �Q�_�̏ꍇ
			if(l[10] * l[11] * l[12] * l[13] == 2){	// ���O�l�������т̏ꍇ
				@fixed_route = l[0]
				@route_established = 1
			}
			else{
				a[@last_select + l[0]] = 1
			}
		}
	}
}

command $route_final_confirmed{

	l[0] = selbtn(
		"�̂̂���񂩂Ȃ��H", @last_select_no, $selected(@select_nono),
		"�ڗ���タ��񂩂��H", @last_select_ru, $selected(@select_ruri),
		"�z�����c�c���ȁH", @last_select_ri, $selected(@select_rin),
		"�݂邿��񂩂��H", @last_select_mi, $selected(@select_milk),
		@selsave)
		
		@fixed_route = l[0]
		return(l[0])

}

// ==========================================================
// ���ՁF�P����
// ----------------------------------------------------------
// �m�m�o��
command $beginning_stage{
	savepoint
//	if(script.check_skip == 0){
		@pcm(ocean_shore)
		@ev(ev011_maimai_01)		//camera up
		$st011_begin_pants_kira
		@wait(2000, 1000)
		@ev(ev011_begin_ferry_01)
		KOE(000100005,000)�y�m�m�H�z�u�`��v
		@wait(1000)
		@bgs(up, 2048 - 720, 10000)
		close
		@pr(st011_begin_logo)
		R
		$play_pcm(ohne)
		clear
		@pr(ohne, 0)
		@bgi(kuro)
//	}
}

command $st011_begin_pants_kira{

	front.object[@obj_no_st].init
	front.object[@obj_no_st].disp = 1
	front.object[@obj_no_st].child.resize(3)
	
	for(l[0] = 0, l[0] < 3, l[0] += 1){
		front.object[@obj_no_st].child[l[0]].create(st000_pants_kira, 1, 0, 0, l[0])
		front.object[@obj_no_st].child[l[0]].tr = 0
		front.object[@obj_no_st].child[l[0]].frame_action.start(-1, "$kirakira", l[0])
	}
}

command $kirakira(property $fa:frameaction, property $obj:object, property $i){

	l[1] = 3600

	l[0] = ($fa.counter.get + $i * l[1] / 3) % l[1]
	
	$obj.tr = math.sin(math.timetable(l[0], 0, 0, [0, l[1], 3600]), 255)
	
}

// �m�m�o�d
command $st011_podium{

@ev(ev011_nonohead_01)
pcmch[0].play(class_door_open)
pcmch[0].wait_key
@ev(ev011_appear_01)
@deco(corner_lace)
pcmch[0].play("6footsteps")
counter[0].reset
counter[0].start_real
counter[0].wait_key(1800)
@ev(ev011_nonowalk_01, 1)
pcmch[0].wait_key
counter[0].stop
pcmch[0].play(chalk_double_speed)
@deco(ohne, 9)
@bgi(bgi09, 9)

	front.object[@obj_no_st].init
	front.object[@obj_no_st].disp = 1
	front.object[@obj_no_st].child.resize(4)
	for(l[0] = 0, l[0] < 4, l[0] += 1){
		front.object[@obj_no_st].child[l[0]].create(st011_nononame, 1, 1600 * l[0], 0, l[0])
	}
	front.object[@obj_no_st].x_eve.set(-6604, 3000, 0, 0, start = 1152)
	//�`���[�N�̉��܂�
	front.object[@obj_no_st].x_eve.wait_key
	pcmch[0].stop
	@ev(ev011_podium_01)


}

command $st011_podium2{

@ev(ev011_nonohead_01)
pcmch[0].play(class_door_open)
pcmch[0].wait_key
@ev(ev011_appear_01)
pcmch[0].play("6footsteps")
counter[0].reset
counter[0].start_real
counter[0].wait_key(1800)
@ev(ev011_nonowalk_01, 1)
pcmch[0].wait_key
counter[0].stop
}

command $st011_flyaway{

	front.object[@obj_no_st].create(bgi01, 1, 1152/2, 720/2)
	front.object[@obj_no_st].tr_eve.set(255, 200, 0, 2, start = 0)
	front.object[@obj_no_st].scale_x_eve.set(1000, 1200, 0, 2, start = 2000)
	front.object[@obj_no_st].scale_y_eve.set(1000, 1200, 0, 2, start = 2000)
//	front.object[@obj_no_st].all_eve



}


command $turn_skirt{

	@ev(ev011_samesan_01)
	$st011_begin_pants_kira
	
}

command $turn_skirt_lion{
	@pcm(�X�J�[�g���߂��鉹)
	@ev(ev011_samesan_02)
	$st011_begin_pants_kira
	
}

command $turn_skirt_usa{
	@pcm(�X�J�[�g���߂��鉹)
	@ev(ev011_samesan_03)
	$st011_begin_pants_kira
	
}

command $turn_skirt_koala{
	@pcm(�X�J�[�g���߂��鉹)
	@ev(ev011_samesan_04)
	$st011_begin_pants_kira
	
}

command $st011_nono_kouka{
/*
0000	�����A�b�v
	100
0100	�o�dCG�F�ᑐ�G���
	8572
8672	�O�l���F�P������
	6402
15074	���PAN
	3471
18545	�w�Z�O�ρ��F�������ȋ���
	4593
23138	�o�X���F�傫��
	4023
27161	���ʔ����F�ӂ����
	4625
31786	�L�����F���炫���
	6914
38700	�u�����F�����悤���傤
	4617
43317	�K�����F�������т�
	4584
47901	�I���K���F�悤���傤
	5354
53255	�����F��������̂͂ȂЂ炭
	5664
58919	�]�C
	6674
65595
*/

//0.5sec	�����A�b�v
//4.5sec	�o�dCG
//9.1sec	200%�\�����Y�[���A�E�g
//15.5sec	���炫��\���ň�C�ɏ�ւ���Ɓ���i�f�ޓ���
//19.0sec	�Z���w�i�H�@35sec
//53.9sec	���F�̉ԂЂ炭�`�͌����A�b�v�ŁY
close
@bgm
bgm.wait_fade
@ev(ev011_outa_01)
@wait(0, 400)
pcmch[0].play(school_song)


l[0] = 0100		// �o�d
l[1] = 8672		// 3nin
l[2] = 15074	// pan
l[3] = 18545	// school
l[4] = 23138	// bus
l[5] = 27161	// getabako
l[6] = 31786	// rouka
l[7] = 38700	// kodo
l[8] = 43317	// shuji
l[9] = 47901	// organ
l[10] = 53255	// kyositu
l[11] = 58919	// yoin


l[0] = 0100		// �o�d
front.object[1].create(st011_outa_podium, 1)
front.object[1].set_center_rep(1152/2, 720/2)

front.object[1].tr_eve.set(255, 500, l[0], 2, start = 0)
front.object[1].scale_x_eve.set(1000, 10000, l[0], 2, start = 1200)
front.object[1].scale_y_eve.set(1000, 10000, l[0], 2, start = 1200)

l[1] = 8672		// 3nin
front.object[2].create(st011_outa_flyhigh, 1, 0, -1328, 2)
front.object[2].set_center_rep(576, 1688)
front.object[2].child.resize(2)
front.object[2].child[0].create(st011_outa_flyhigh, 1, 0, 0, 1)
//front.object[2].child[1].create(st011_outa_flyhigh, 1, 0, 0, 0)

front.object[2].tr_eve.set(255, 500, l[1], 2, start = 0)
front.object[2].scale_x_eve.set(1000, l[2] - l[1], l[1], 2, start = 1200)
front.object[2].scale_y_eve.set(1000, l[2] - l[1], l[1], 2, start = 1200)

l[2] = 15074	// pan
front.object[3].create(st011_outa_flyhigh, 1, 0, -1328, 2)
front.object[3].set_center_rep(576, 1688)
front.object[3].child.resize(2)
front.object[3].child[0].create(st011_outa_flyhigh, 1, 0, 0, 1)
front.object[3].child[1].create(st011_outa_flyhigh, 1, 0, 0, 0)

front.object[3].tr_eve.set(255, 500, l[2], 1, start = 0)
front.object[3].y_eve.set(0, l[3] - l[2], l[2], 2, start = -1328)

l[3] = 18545	// school
front.object[4].create(st011_outa_school, 1, -50, 0)

front.object[4].tr_eve.set(255, 500, l[3], 2, start = 0)
front.object[4].y_eve.set(-300, l[4]- l[3], l[3], 0, start = 0)

l[4] = 23138	// bus
front.object[5].create(st011_outa_bus, 1, 285, 0, 0)

front.object[5].tr_eve.set(255, 500, l[4], 2, start = 0)
front.object[5].x_eve.set(0, l[5] - l[4], l[4], 0, start = -285)

l[5] = 27161	// getabako
front.object[6].create(st011_outa_getabako, 1, 0, -200, 0)

front.object[6].tr_eve.set(255, 500, l[5], 2, start = 0)
front.object[6].x_eve.set(-300, l[6] - l[5], l[5], 0, start = 0)

l[6] = 31786	// rouka
front.object[7].create(st011_outa_way, 1, -100, -100, 0)

front.object[7].tr_eve.set(255, 500, l[6], 2, start = 0)
front.object[7].scale_x_eve.set(1200, l[7] - l[6], l[6], 0, start = 900)
front.object[7].scale_y_eve.set(1200, l[7] - l[6], l[6], 0, start = 900)

l[7] = 38700	// kodo
front.object[8].create(st011_outa_kodo, 1, 285, 0, 0)

front.object[8].tr_eve.set(255, 500, l[7], 2, start = 0)
front.object[8].x_eve.set(0, l[8] - l[7], l[7], 0, start = -285)

l[8] = 43317	// shuji
front.object[9].create(st011_outa_shuji, 1, -55, 0, 0)

front.object[9].tr_eve.set(255, 500, l[8], 2, start = 0)
front.object[9].scale_x_eve.set(1200, l[9] - l[8], l[8], 0, start = 900)
front.object[9].scale_y_eve.set(1200, l[9] - l[8], l[8], 0, start = 900)


l[9] = 47901	// organ
front.object[10].create(st011_outa_organ, 1, 5, 0, 0)

front.object[10].tr_eve.set(255, 500, l[9], 2, start = 0)
front.object[10].scale_x_eve.set(1000, l[10] - l[9], l[9], 0, start = 1200)
front.object[10].scale_y_eve.set(1000, l[10] - l[9], l[9], 0, start = 1200)

l[10] = 53255	// kyositu
front.object[11].create(bgi09, 1, 0, 360)

front.object[11].tr_eve.set(255, 500, l[10], 2, start = 0)
front.object[11].x_eve.set(1152/2, l[11] - l[10], l[10], 2, start = 1252/2)

l[11] = 58919	// yoin

pcmch[0].wait_key
pcmch[0].stop
}



// �Ԗʔ���
command $st011_nono_blush{


}

command $st011_nopants{

	@ev(ev011_podium_98)
	front.object[@obj_no_st].create(st011_nopantu, 1)
	front.object[@obj_no_st].child.resize(1)
//	front.object[@obj_no_st].child[0].create(_for_niconama, 1, 0, 0, 1)//�j�R���p
	front.object[@obj_no_st].x_eve.set(0, @time_ev, 0, 2, start = -500)
	front.object[@obj_no_st].tr_eve.set(255, @time_ev / 5, 0, 2, start = 0)
	front.object[@obj_no_bg].x_eve.set(300, @time_ev * 4 / 5, @time_ev / 5, 1, start = 0)
	
	@sawcg(ev011_podium_99)

}

// ----------------------------------------------------------

command $st012_handstand{

	@ev(ev012_handstand_01)
	$st011_begin_pants_kira


}

command $st012_okosama_lunch{

	back.object[@obj_no_bg].init
	back.object[@obj_no_bg].disp = 1
	back.object[@obj_no_bg].set_pos(0, 0)
	back.object[@obj_no_bg].child.resize(3)
	
	back.object[@obj_no_bg].child[0].create(st012_lunch_bg, 1, 0, 140)
	back.object[@obj_no_bg].child[2].create(st012_lunch_okosama, 1, 0, 40)
	
	back.object[@obj_no_bg].child[1].create(st012_lunch_01, 1, 0, 200)

	close
	
	$wipe(1, 3, 0)
	
	@wait(100, 100)
	
	front.object[@obj_no_bg].child[0].y_eve.set(0, @time_ev, 0, 0)
	front.object[@obj_no_bg].child[1].y_eve.set(0, @time_ev, 0, 0)
	front.object[@obj_no_bg].child[2].y_eve.set(0, @time_ev, 0, 0)
	front.object[@obj_no_bg].child[1].y_eve.wait_key

	@sawcg(ev012_lunch_01)

}

// ==========================================================
// ���ՁF�Q����
// ----------------------------------------------------------
// �����낭�z�Ƃ݂邭�̃L�X
command $st021_rin_mil_kiss(property $i){

	if($i == 1){	// �\��
	
		cgtable.set_look_by_name(ev021_kiss_01, 1)
	
		back.object[@obj_no_bg].create(st021_kiss_bg, 1)
		back.object[@obj_no_bg].child.resize(4)
		back.object[@obj_no_bg].child[0].create(_null)
	
		back.object[@obj_no_bg].child[1].create(st021_kiss_ri, 1)
		back.object[@obj_no_bg].child[2].create(st021_kiss_mi, 1)
		
		$wipe(1, 3, 0)
	
	}
	elseif($i == 2){	// �z�������鍶�ւU�O����
		
		front.object[@obj_no_bg].child[1].x_eve.set(-180, @time_ev, 0, 1, start = 0)
		front.object[@obj_no_bg].child[2].x_eve.set(-180, @time_ev * 2, @time_ev, 1, start = 0)
		
	}
	elseif($i == 3){
	
	}
}

// ==========================================================
// �F�m�m
// ----------------------------------------------------------
// �m�m�d�m�c��
command $nono_end_pan{

	front.object[@obj_no_fore].create(st011_outa_flyhigh, 1, 0, 720-2048, 2)
	front.object[@obj_no_fore].layer = @lay_no_fore
	front.object[@obj_no_fore].tr_eve.set(255, @time_ev/2, 0, 0, start = 0)
	front.object[@obj_no_fore].y_eve.set(0, @time_ev, 0, 1, start = 720-2048)

}


// ==========================================================
// �F�ڗ����
// ----------------------------------------------------------
// �����[�S�[�����h
command $merry_piston_start{

	back.object[@obj_no_bg].create(st226_merry_bg, 1, 0, 0, 0)
	back.object[@obj_no_bg].child.resize(3)
	// �ڗ����
	back.object[@obj_no_bg].child[0].init
	back.object[@obj_no_bg].child[0].disp = 1
	back.object[@obj_no_bg].child[0].child.resize(2)
	back.object[@obj_no_bg].child[0].child[0].create(st226_merry_21, 1)
	
	// �J�b�g�C��
	back.object[@obj_no_bg].child[1].init
	back.object[@obj_no_bg].child[1].disp = 1
	back.object[@obj_no_bg].child[1].child.resize(2)
	back.object[@obj_no_bg].child[1].child[0].create(st226_merry_21_cut, 1)
	
	wipe(0, @time_ev)
	
	front.object[@obj_no_bg].wipe_copy = 1
	
	front.object[@obj_no_bg].child[0].frame_action.start(-1, "$merry_motion")
	
}

command $merry_motion(
	property $fa:frameaction,
	property $obj:object){
	
	l[10] = 6000
	
	l[0] = $fa.counter.get % l[10]
	l[1] = math.timetable(l[0], 0, 0, [0, l[10], 3600])
	$obj.x = math.sin(l[1], 20)
	$obj.y = math.sin(l[1], 20)
	
}

command $merry_change(property $i){

	if($i == 310){
		front.object[@obj_no_bg].child[2].create(siro, 1)
		front.object[@obj_no_bg].child[0].child[0].create(st226_merry_31, 1)
		front.object[@obj_no_bg].child[1].child[0].create(st226_merry_31_cut, 1)
		front.object[@obj_no_bg].child[2].tr_eve.set(0, @time_ev * 2, 0, 0, start = 255)
		
		@sawcg(ev226_merry_31)
	}
	else{

	k[0] = "st226_merry_" + math.tostr_zero($i, 2)
	front.object[@obj_no_bg].child[0].child[1].create_copy_from(front.object[@obj_no_bg].child[0].child[0])
	front.object[@obj_no_bg].child[0].child[0].create(k[0], 1)
	front.object[@obj_no_bg].child[0].child[1].tr_eve.set(0, @time_ev, 0, 0, start = 255)
//	front.object[@obj_no_bg].child[0].change_file(k[0])
	
//	if($i == 31){
//		front.object[@obj_no_bg].child[1].child[1].create_copy_from(front.object[@obj_no_bg].child[0].child[0])
//		front.object[@obj_no_bg].child[1].child[0].create(st226_merry_31_cut, 1)
//		front.object[@obj_no_bg].child[1].child[1].tr_eve.set(0, @time_ev, 0, 0, start = 255)
//		front.object[@obj_no_bg].child[1].change_file(st226_merry_31_cut)
//	}
	
	k[1] = "ev226_merry_" + math.tostr_zero($i, 2)
	@sawcg(k[1])

	}
}
#z00
