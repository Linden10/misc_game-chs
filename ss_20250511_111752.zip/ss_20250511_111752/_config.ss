// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
// _/
//		���ݒ�
// _/
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

// ==========================================================
// ��`
// ----------------------------------------------------------
#inc_start

	// �I�u�W�F�N�g
	#define		@obj_bg					000
	#define		@obj_above_menu			001
	#define		@obj_below_menu			002
	#define		@obj_config				003
	
	// �q�I�u�W�F�N�g�F�V�X�e��
	#define		@c_txt					000
	
	#define		@c_window				001
	#define		@c_full					002
	#define		@c_screen				003
	#define		@c_show_start			004//3x3
	#define		@c_show_ch				004
	#define		@c_show_ev				007
	#define		@c_show_sys				010
	#define		@c_msg_skip				013
	#define		@c_auto_save			015
	#define		@c_selected				017
	#define		@c_fixed				019
	#define		@c_spot					021//2x2
	#define		@c_rclick				025//5
	#define		@c_confirm				030//8
	#define		@c_other				038//4
	
	// �q�I�u�W�F�N�g�F�e�L�X�g
	#define		@c_msg_spd_default		001
	#define		@c_msg_spd_nowait		002
	#define		@c_msg_spd_slider		003
	#define		@c_msg_spd_cursor		004
	
	#define		@c_filter_default		005
	#define		@c_filter_slider		006
	#define		@c_filter_cursor		007
	
	#define		@c_font_set				008
	
	#define		@c_auto_default			009
	#define		@c_auto_onoff			010
	#define		@c_auto_moji_slider		011
	#define		@c_auto_moji_cursor		012
	#define		@c_auto_min_slider		013
	#define		@c_auto_min_cursor		014
	#define		@c_auto_moji_sec		015//3
	#define		@c_auto_min_sec			018//3
	#define		@c_auto_10moji_sec		021//3
	
	#define		@c_sample_filter		024
	#define		@c_sample_cover			025
	#define		@c_sample_msg			026
	
	// �q�I�u�W�F�N�g�F�T�E���h
	#define		@c_vol_default			001

	#define		@c_vol_all				002//4
	#define		@c_vol_bgm				006
	#define		@c_vol_fade				010
	#define		@c_vol_se				014
	#define		@c_vol_bgse				018
	#define		@c_vol_vo				022
	#define		@c_vol_bgv				026
	#define		@c_vol_movie			030
	#define		@c_vol_sys				034

	#define		@c_chara_default		038
	#define		@c_chara_all_on			039
	#define		@c_chara_all_off		040

	#define		@c_chara_nono			041//4
	#define		@c_chara_rin			045
	#define		@c_chara_ruri			049
	#define		@c_chara_milk			053
	#define		@c_chara_other			057

	#define		@c_koe_keep				061
	
	#define		@c_vol_fade_use			062
	
	#define		@c_mama_use				001
	#define		@c_mama_dummy			002
	#define		@c_mama_crash			003
	#define		@c_mama_thum_start		004//4
	
	// �{�^���F����
	#define		@btn_cancel				-1
	
	#define		@btn_menu_start			000
	#define		@btn_menu_system		000
	#define		@btn_menu_txt			001
	#define		@btn_menu_sound			002
	#define		@btn_menu_mama			003
	
	#define		@btn_sc_start			004
	#define		@btn_sc_quit			004
	#define		@btn_sc_title			005
	#define		@btn_sc_save			006
	#define		@btn_sc_load			007
	#define		@btn_sc_config			008
	#define		@btn_sc_return			009
	
	// �{�^���F�V�X�e��
	#define		@btn_window				100
	#define		@btn_full				101
	#define		@btn_screen				102
	
	#define		@btn_show_spd_start		110
	#define		@btn_show_spd_diff		5
	#define		@btn_show_spd_ch		110
	#define		@btn_show_spd_ev		115
	#define		@btn_show_spd_sys		120
	
	#define		@btn_msg_skip_already	130
	#define		@btn_msg_skip_unread	131
	
	#define		@btn_auto_save_use		140
	#define		@btn_auto_save_dis		141
	
	#define		@btn_selected_change	150
	#define		@btn_selected_steady	151
	
	#define		@btn_spot_fixed_on		160
	#define		@btn_spot_fixed_off		161
	#define		@btn_spot_fixed_place	162//-165
	#define		@btn_spot_fixed_creampie	162
	#define		@btn_spot_fixed_bukkake		164
	
	#define		@btn_rclick_start		170
	#define		@btn_rclick_window		170
	#define		@btn_rclick_config		171
	#define		@btn_rclick_save		172
	#define		@btn_rclick_load		173
	#define		@btn_rclick_log			174
	#define		@btn_rclick_end			174
	
	#define		@btn_confirm_start		180
	#define		@btn_confirm_load		180
	#define		@btn_confirm_overwrite	181
	#define		@btn_confirm_qsave		182
	#define		@btn_confirm_qload		183
	#define		@btn_confirm_del		184
	#define		@btn_confirm_rewind		185
	#define		@btn_confirm_title		186
	#define		@btn_confirm_quit		187
	#define		@btn_confirm_end		187
	
	#define		@btn_other_mouse		190
	#define		@btn_other_cursor		191
	#define		@btn_other_priority		192
	#define		@btn_other_movie		193
	
	// �{�^���F�e�L�X�g
	#define		@btn_msg_spd_default	200
	#define		@btn_msg_spd_nowait		201
	#define		@btn_msg_spd_slider		202
	#define		@btn_msg_spd_cursor		203

	#define		@btn_filter_default		220
	#define		@btn_filter_slider		221
	#define		@btn_filter_cursor		222

	#define		@btn_font_set			230

	#define		@btn_auto_default		240
	#define		@btn_auto_onoff			241
	#define		@btn_auto_moji_slider	242
	#define		@btn_auto_moji_cursor	243
	#define		@btn_auto_min_slider	244
	#define		@btn_auto_min_cursor	245
	
	// �{�^���F�T�E���h
	#define		@btn_vol_default		300
	#define		@btn_vol_all			310
	#define		@btn_vol_bgm			320
	#define		@btn_vol_fade			330
	#define		@btn_vol_se				340
	#define		@btn_vol_bgse			350
	#define		@btn_vol_vo				360
	#define		@btn_vol_bgv			370
	#define		@btn_vol_movie			380
	#define		@btn_vol_sys			390
	
	#define		@btn_chara_default		400
	#define		@btn_chara_all_on		401
	#define		@btn_chara_all_off		402
	
	#define		@btn_chara_nono			410
	#define		@btn_chara_rin			420
	#define		@btn_chara_ruri			430
	#define		@btn_chara_milk			440
	#define		@btn_chara_other		450
	
	#define		@btn_koe_keep			460
	#define		@btn_fade_use			470
	
	#define		@btn_mama_use			500
	#define		@btn_mama_dummy			501
	#define		@btn_mama_crash			502
	#define		@btn_mama_thum_start	510
	
	// �X���C�_�[���ꂱ��
	#define		@slide_width_w			135
	#define		@slide_width_t			150
	#define		@slide_spd_pos			(272+17)
	#define		@slide_moji_pos			(800+17)
	
	#define		@slide_width			(147-27)
	#define		@slide_vol_pos			(247+14)
	#define		@slide_width_s			(147-23)
	#define		@slide_vol_pos_s		(247+12)
	#define		@slide_chara_pos		(800+14)
	
	#define		@vol_mute_x				194
	#define		@vol_slide_x			213
	#define		@vol_test_x				434
	
	#define		@chara_mute_x			747
	#define		@chara_slide_x			767
	#define		@chara_test_x			989
	
	#define		@mama_thum_num				4
	
	#define		@title_pos_x			-58
	#define		@title_pos_y			-38
	
	#property	$push_btn_no
	#property	$push_btn_x
	#property	$push_mouse_x
	#property	$open_page
	

#inc_end


// ==========================================================
// �E�B���h�E�{�^���Ȃǂ���Ăяo���̂͂�������
// ----------------------------------------------------------
#z00

	$excall_ready		// �V�X�e���R�[��������
	gosub #z01			// �{�̂�
	$excall_wipe		// ���C�v���ďI��
	$excall_free		// �V�X�e���R�[�������
	return				// �V�X�e���R�[�����甲����


// ==========================================================
// ���̂d�w�R�[������Ăяo���ꍇ�͂���
// ----------------------------------------------------------
//
#z01

	excall.back.objbtngroup[0].init

	// �w�i
//	excall.back.object[@obj_bg].create_rect(0, 0, 1152, 720, 0, 0, 0, 128, 1)
	
	$open_page = @config_last_page
	// �チ�j���[
	$above_menu_disp(0)
	// �����j���[
	$below_menu_disp(0)
	
	// ���C��
	switch($open_page){
		case(00)	$system_menu_disp(0)
		case(01)	$text_menu_disp(0)
		case(02)	$sound_menu_disp(0)
		case(03)	$mama_menu_disp(0)
	}

	$excall_wipe
	
	excall.front.objbtngroup[0].start_cancel
	
	excall.counter[0].start
	
	while(1){
	
		$mama_key_check
		
		switch($open_page){
			case(0)	$window_surve
			case(1)	$update_text_object(1)
			case(2)	$update_sound_object(1)
		}
		
		l[0] = excall.front.objbtngroup[0].get_hit_no
		l[1] = excall.front.objbtngroup[0].get_pushed_no
		l[2] = excall.front.objbtngroup[0].get_decided_no
		
		switch($open_page){
			case(0)		$system_menu_decision(l[2])
			case(1)		$text_menu_decision(l[1], l[2])
			case(2)		$sound_menu_decision(l[1], l[2])
			case(3)		$mama_menu_decision(l[2])
		}
		
		// ��Ӄ��j���[
		if(l[2] == @btn_menu_system){
			$open_page = 0
			$system_menu_disp(1)
			$above_menu_disp(1)
			$below_menu_disp(1)
		}
		if(l[2] == @btn_menu_txt){
			$open_page = 1
			$text_menu_disp(1)
			$above_menu_disp(1)
			$below_menu_disp(1)
		}
		if(l[2] == @btn_menu_sound){
			$open_page = 2
			$sound_menu_disp(1)
			$above_menu_disp(1)
			$below_menu_disp(1)
		}
		if(l[2] == @btn_menu_mama){
			$open_page = 3
			$mama_menu_disp(1)
			$above_menu_disp(1)
			$below_menu_disp(1)
		}
		
		// ���ӃV���[�g�J�b�g
		if(l[2] == @btn_sc_quit){
			$end_game(1)
		}
		if(l[2] == @btn_sc_title){
			$return_title(1)
		}
		if(l[2] == @btn_sc_save){
			jump(_save, 01)//syscom.call_save_menu//jump(_save, 01)
		}
		if(l[2] == @btn_sc_load){
			jump(_load, 01)//syscom.call_load_menu//jump(_load, 01)
		}
		if(l[2] == @btn_sc_config){
			$open_page = 0
			$above_menu_disp(1)
			$below_menu_disp(1)
			$system_menu_disp(1)
		}
		
		// �L�����Z��
		if(l[2] == @btn_cancel || l[2] == @btn_sc_return){
			break
		}
		
		// �z�C�[�����񂵂��ꍇ
		if(mouse.wheel < 0){
			$open_page += -1
			if($open_page < 0){
				$open_page = 3
			}
			switch($open_page){
				case(0)	$system_menu_disp(1)
				case(1)	$text_menu_disp(1)
				case(2)	$sound_menu_disp(1)
				case(3) $mama_menu_disp(1)
			}
			$above_menu_disp(1)
		}
		if(mouse.wheel > 0){
			$open_page += 1
			if($open_page > 3){
				$open_page = 0
			}
			switch($open_page){
				case(0)	$system_menu_disp(1)
				case(1)	$text_menu_disp(1)
				case(2)	$sound_menu_disp(1)
				case(3) $mama_menu_disp(1)
			}
			$above_menu_disp(1)
		}
		
		// �I���ĊJ
		if(l[2] >= 0){	// ���肵���ꍇ�A�I�����ĊJ
			excall.front.objbtngroup[0].init
			excall.front.objbtngroup[0].start_cancel
		}

		disp

	}
	

return


// ==========================================================
// ���L�p�[�c
// ----------------------------------------------------------
command $above_menu_disp(property $i){

	excall.stage[$i].object[@obj_above_menu].init
	excall.stage[$i].object[@obj_above_menu].disp = 1
	excall.stage[$i].object[@obj_above_menu].set_pos(684, 55)
	excall.stage[$i].object[@obj_above_menu].child.resize(4)
	
	for(l[0] = 0, l[0] < 4, l[0] += 1){
		excall.stage[$i].object[@obj_above_menu].child[l[0]].create(_config_btn_config_menu, 1, 113 * l[0], 0, 2 * l[0])
		excall.stage[$i].object[@obj_above_menu].child[l[0]].set_button(@btn_menu_start + l[0], 0, 2, 0)
	}
	
	// ���s�\���ӏ���{�^��
	excall.stage[$i].object[@obj_above_menu].child[$open_page].patno += 1
	excall.stage[$i].object[@obj_above_menu].child[$open_page].clear_button

}

command $below_menu_disp(property $i){

	excall.stage[$i].object[@obj_below_menu].init
	excall.stage[$i].object[@obj_below_menu].disp = 1
	excall.stage[$i].object[@obj_below_menu].set_pos(458, 650)
	excall.stage[$i].object[@obj_below_menu].child.resize(6)

	for(l[0] = 0, l[0] < 6, l[0] += 1){
		excall.stage[$i].object[@obj_below_menu].child[l[0]].create(_config_btn_sc_menu, 1, 113 * l[0], 0, l[0] * 2)
		excall.stage[$i].object[@obj_below_menu].child[l[0]].set_button(@btn_sc_start + l[0], 0, 2, 0)
	}
	if(@��z��){
		excall.stage[$i].object[@obj_below_menu].child[1].patno = 12
	}
	
	// �Z�[�u��
	if(@���j���[��){
		excall.stage[$i].object[@obj_below_menu].child[2].set_button_state_disable
	}
	if(@��z��){
		excall.stage[$i].object[@obj_below_menu].child[3].set_button_state_disable
	}
	
	// �R���t�B�O��ʂȂ̂Ŕ�A�N�e�B�u
	excall.stage[$i].object[@obj_below_menu].child[4].set_button_state_disable
	excall.stage[$i].object[@obj_below_menu].child[4].set_button(@btn_sc_config, 0, 2, 0)
	excall.stage[$i].object[@obj_below_menu].child[4].patno += 1
	
}

// ==========================================================
// �V�X�e�����j���[
// ----------------------------------------------------------
command $system_menu_disp(property $i){

	@config_last_page = 0
	
	excall.stage[$i].object[@obj_bg].create(_config_bg_filter, 1)//, 1, _rect(0, 0, 1152, 720, 0, 0, 0, 128, 1)

	excall.stage[$i].object[@obj_config].create(_config_base_bg, 1, 0, 90, 0)
	excall.stage[$i].object[@obj_config].child.resize(42)
	
	// ����
	excall.stage[$i].object[@obj_config].child[@c_txt].create(_config_base_sys_txt, 1, 70, 55)
	excall.stage[$i].object[@obj_config].child[@c_txt].child.resize(1)
	excall.stage[$i].object[@obj_config].child[@c_txt].child[0].create(_config_base_title_config, 1, @title_pos_x, @title_pos_y)
	
	// ��ʃ��[�h
	excall.stage[$i].object[@obj_config].child[@c_window].create(_config_btn_window, 1, 214, 105, 0)
	excall.stage[$i].object[@obj_config].child[@c_full].create(_config_btn_window, 1, 364, 105, 2)
	excall.stage[$i].object[@obj_config].child[@c_screen].create(_config_btn_window, 1, 513, 105, 4)
	
	excall.stage[$i].object[@obj_config].child[@c_window].set_button(@btn_window, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_full].set_button(@btn_full, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_screen].set_button(@btn_screen, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_window + syscom.get_window_mode].patno += 1
	excall.stage[$i].object[@obj_config].child[@c_window + syscom.get_window_mode].clear_button
	
	// �\�����x
	l[5] = @c_show_start
	l[6] = 3
	l[10] = 276		// �������W�@��
	l[11] =  88
	l[20] = 185		// �������W�@��
	l[21] =  31
	
	for(l[0] = 0, l[0] < 3, l[0] += 1){
		for(l[1] = 0, l[1] < 3, l[1] += 1){
			l[2] = l[5] + l[0] * l[6] + l[1]
			excall.stage[$i].object[@obj_config].child[l[2]].create(_config_btn_show_spd, 1, l[10] + l[11] * l[1], l[20] + l[21] * l[0], l[1] * 2)
			excall.stage[$i].object[@obj_config].child[l[2]].set_button(@btn_show_spd_start + l[1] + @btn_show_spd_diff * l[0], 0, 2, 0)
			
			if(@show_spd_start(l[0]) == l[1]){
				excall.stage[$i].object[@obj_config].child[l[2]].patno += 1
				excall.stage[$i].object[@obj_config].child[l[2]].clear_button
			}
		}
	}
	
	// ���b�Z�[�W�X�L�b�v
	excall.stage[$i].object[@obj_config].child[@c_msg_skip].create(_config_btn_msg_skip, 1, 276, 298, 0)
	excall.stage[$i].object[@obj_config].child[@c_msg_skip + 1].create(_config_btn_msg_skip, 1, 426, 298, 2)
	excall.stage[$i].object[@obj_config].child[@c_msg_skip].set_button(@btn_msg_skip_already, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_msg_skip + 1].set_button(@btn_msg_skip_unread, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_msg_skip + syscom.get_skip_unread_message_onoff].patno += 1
	excall.stage[$i].object[@obj_config].child[@c_msg_skip + syscom.get_skip_unread_message_onoff].clear_button
	
	// �I�[�g�Z�[�u
	excall.stage[$i].object[@obj_config].child[@c_auto_save + 1].create(_config_btn_auto_save, 1, 276, 342, 0)
	excall.stage[$i].object[@obj_config].child[@c_auto_save].create(_config_btn_auto_save, 1, 426, 342, 2)
	
	excall.stage[$i].object[@obj_config].child[@c_auto_save + 1].set_button(@btn_auto_save_use, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_auto_save].set_button(@btn_auto_save_dis, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_auto_save + @autosave_use].patno += 1
	excall.stage[$i].object[@obj_config].child[@c_auto_save + @autosave_use].clear_button
	
	// �I���ςݑI����
	excall.stage[$i].object[@obj_config].child[@c_selected + 1].create(_config_btn_selected, 1, 276, 387, 0)
	excall.stage[$i].object[@obj_config].child[@c_selected].create(_config_btn_selected, 1, 426, 387, 2)
	
	excall.stage[$i].object[@obj_config].child[@c_selected + 1].set_button(@btn_selected_change, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_selected].set_button(@btn_selected_steady, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_selected + @selected_choice].patno += 1
	excall.stage[$i].object[@obj_config].child[@c_selected + @selected_choice].clear_button
	
	// �I�����Œ�
	excall.stage[$i].object[@obj_config].child[@c_fixed].create(_config_btn_spot_onoff, 1, 276, 442, 0)
	excall.stage[$i].object[@obj_config].child[@c_fixed + 1].create(_config_btn_spot_onoff, 1, 426, 442, 2)
	
	excall.stage[$i].object[@obj_config].child[@c_fixed + 1 - @spot_fixed_onoff].patno += 1
	excall.stage[$i].object[@obj_config].child[@c_fixed + @spot_fixed_onoff].set_button(@btn_spot_fixed_on + @spot_fixed_onoff, 0, 2, 0)
	
	// �I�����Œ�F���̏ꏊ
	excall.stage[$i].object[@obj_config].child[@c_spot].create(_config_btn_spot_place, 1, 162, 472, 0)
	excall.stage[$i].object[@obj_config].child[@c_spot + 1].create(_config_btn_spot_place, 1, 249, 472, 2)

	excall.stage[$i].object[@obj_config].child[@c_spot + 2].create(_config_btn_spot_place, 1, 360, 472, 4)
	excall.stage[$i].object[@obj_config].child[@c_spot + 3].create(_config_btn_spot_place, 1, 447, 472, 6)
	
	excall.stage[$i].object[@obj_config].child[@c_spot + 1 - @spot_fixed_creampie].set_button(@btn_spot_fixed_place + 1 - @spot_fixed_creampie, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_spot + @spot_fixed_creampie].patno += 1

	excall.stage[$i].object[@obj_config].child[@c_spot + 2 + 1 - @spot_fixed_bukkake].set_button(@btn_spot_fixed_place + 2 + 1 - @spot_fixed_bukkake, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_spot + 2 + @spot_fixed_bukkake].patno += 1
	
	if(@spot_fixed_onoff == 0){
		for(l[0] = 0, l[0] < 4, l[0] += 1){
			excall.stage[$i].object[@obj_config].child[@c_spot + l[0]].clear_button
			excall.stage[$i].object[@obj_config].child[@c_spot + l[0]].dark = 48
		}
	}
	
	// �E�N���b�N����
	l[10] = 710
	l[11] = 170
	l[20] = 135
	l[21] =  32
	
	for(l[0] = 0, l[0] < 5, l[0] += 1){
		excall.stage[$i].object[@obj_config].child[@c_rclick + l[0]].create(_config_btn_rclick, 1)
		excall.stage[$i].object[@obj_config].child[@c_rclick + l[0]].patno = 2 * l[0]
		excall.stage[$i].object[@obj_config].child[@c_rclick + l[0]].set_button(@btn_rclick_start + l[0], 0, 2, 0)
		excall.stage[$i].object[@obj_config].child[@c_rclick + l[0]].set_pos(l[10] + l[0] % 2 * l[11], l[20] + l[0] / 2 * l[21])
	}
	
	excall.stage[$i].object[@obj_config].child[@c_rclick + @rclick_work].patno += 1
	excall.stage[$i].object[@obj_config].child[@c_rclick + @rclick_work].clear_button
	
	// �m�F���b�Z�[�W
	l[10] = 677
	l[11] = 205
	l[20] = 281
	l[21] =  34
	
	for(l[0] = 0, l[0] < 8, l[0] += 1){
		excall.stage[$i].object[@obj_config].child[@c_confirm + l[0]].create(_config_btn_confirm, 1)
		excall.stage[$i].object[@obj_config].child[@c_confirm + l[0]].patno = 2 * l[0]
		excall.stage[$i].object[@obj_config].child[@c_confirm + l[0]].set_button(@btn_confirm_start + l[0], 0, 2, 0)
		excall.stage[$i].object[@obj_config].child[@c_confirm + l[0]].set_pos(l[10] + l[0] % 2 * l[11], l[20] + l[0] / 2 * l[21])
		if(@confirm_start(l[0])){
			excall.stage[$i].object[@obj_config].child[@c_confirm + l[0]].patno += 1
		}
	}
	
	// ���̑��̐ݒ�
	excall.stage[$i].object[@obj_config].child[@c_other].create(_config_btn_mouse, 1, 677, 454, syscom.get_wheel_next_message_onoff)
	excall.stage[$i].object[@obj_config].child[@c_other].set_button(@btn_other_mouse, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_other + 1].create(_config_btn_priority, 1, 882, 460, syscom.get_sleep_onoff)
	excall.stage[$i].object[@obj_config].child[@c_other + 1].set_button(@btn_other_priority, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_other + 2].create(_config_btn_cursor_hide, 1, 677, 485, syscom.get_mouse_cursor_hide_onoff)
	excall.stage[$i].object[@obj_config].child[@c_other + 2].set_button(@btn_other_cursor, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_other + 3].create(_config_btn_movie, 1, 980, 433)
	excall.stage[$i].object[@obj_config].child[@c_other + 3].set_button(@btn_other_movie, 0, 2, 0)

}
	
	
// ==========================================================
// �e�L�X�g���j���[
// ----------------------------------------------------------
command $text_menu_disp(property $i){

	@config_last_page = 1

	excall.stage[$i].object[@obj_bg].create(_config_bg_filter_txt, 1)

	// �y��
	excall.stage[$i].object[@obj_config].create(_config_base_bg_txt, 1, 0, 90, 0)
	excall.stage[$i].object[@obj_config].child.resize(28)
	
	// ����
	excall.stage[$i].object[@obj_config].child[@c_txt].create(_config_base_txt_txt, 1, 70, 55)
	excall.stage[$i].object[@obj_config].child[@c_txt].child.resize(1)
	excall.stage[$i].object[@obj_config].child[@c_txt].child[0].create(_config_base_title_config, 1, @title_pos_x, @title_pos_y)
	
	// �������x�F�����ݒ�
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_default].create(_config_btn_default, 1, 438, 106)
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_default].set_button(@btn_msg_spd_default, 0, 2, 0)
	
	// �������x�F�`�F�b�N�{�b�N�X
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_nowait].create(_config_btn_nowait, 1, 107, 142)
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_nowait].set_button(@btn_msg_spd_nowait, 0, 2, 0)
	
	// �������x�F�X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_slider].create(_config_btn_slider_wide, 1, 241, 146)
	
	// �������x�Fcursor
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_cursor].create(_config_btn_slide_icon, 1, 0, 154)
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_cursor].set_button(@btn_msg_spd_cursor, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_cursor].set_button_pushkeep(1)
	
	// �t�B���^�[�F�����ݒ�
	excall.stage[$i].object[@obj_config].child[@c_filter_default].create(_config_btn_default, 1, 438, 199)
	excall.stage[$i].object[@obj_config].child[@c_filter_default].set_button(@btn_filter_default, 0, 2, 0)
	
	// �t�B���^�[�F�X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_filter_slider].create(_config_btn_slider_wide, 1, 241, 235, 1)
	
	// �t�B���^�[�Fcursor
	excall.stage[$i].object[@obj_config].child[@c_filter_cursor].create(_config_btn_slide_icon, 1, 0, 244)
	excall.stage[$i].object[@obj_config].child[@c_filter_cursor].set_button(@btn_filter_cursor, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_filter_cursor].set_button_pushkeep(1)
	
	// �t�H���g
	excall.stage[$i].object[@obj_config].child[@c_font_set].create(_config_btn_font_set, 1, 241, 290)
	excall.stage[$i].object[@obj_config].child[@c_font_set].set_button(@btn_font_set, 0, 2, 0)
	
	// �I�[�g���[�h�F�����ݒ�
	excall.stage[$i].object[@obj_config].child[@c_auto_default].create(_config_btn_default, 1, 988, 106)
	excall.stage[$i].object[@obj_config].child[@c_auto_default].set_button(@btn_auto_default, 0, 2, 0)
	
	// �I�[�g���[�h�F���񂨂�
	excall.stage[$i].object[@obj_config].child[@c_auto_onoff].create(_config_btn_automode, 1, 597, 130)
	excall.stage[$i].object[@obj_config].child[@c_auto_onoff].set_button(@btn_auto_onoff, 0, 2, 0)
	
	// �I�[�g���[�h�F�������ԁF�X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_slider].create(_config_btn_slider_long, 1, 768, 237)
	
	// �I�[�g���[�h�F�������ԁF�J�[�\��
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_cursor].create(_config_btn_slide_icon, 1, 0, 245)
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_cursor].set_button(@btn_auto_moji_cursor, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_cursor].set_button_pushkeep(1)
	
	// �I�[�g���[�h�F�ŏ����ԁF�X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_auto_min_slider].create(_config_btn_slider_long, 1, 768, 270)
	
	// �I�[�g���[�h�F�ŏ����ԁF�J�[�\��
	excall.stage[$i].object[@obj_config].child[@c_auto_min_cursor].create(_config_btn_slide_icon, 1, 0, 278)
	excall.stage[$i].object[@obj_config].child[@c_auto_min_cursor].set_button(@btn_auto_min_cursor, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_auto_min_cursor].set_button_pushkeep(1)
	
	// ��������
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_sec].create(_config_sec_num, 1, 699, 241, 0)
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_sec + 1].create(_config_sec_num, 1, 711, 241, 10)
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_sec + 2].create_number(_config_sec_num, 1, 716, 241)
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_sec + 2].set_number(syscom.get_auto_mode_moji_wait / 10)
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_sec + 2].set_number_param(2, 1, 0, 0, 0, 0)
	
	// �ŏ�����
	excall.stage[$i].object[@obj_config].child[@c_auto_min_sec].create_number(_config_sec_num, 1, 699, 274)
	excall.stage[$i].object[@obj_config].child[@c_auto_min_sec].set_number(syscom.get_auto_mode_min_wait / 100)
	excall.stage[$i].object[@obj_config].child[@c_auto_min_sec].set_number_param(2, 1, 0, 0, 0, 4)
	excall.stage[$i].object[@obj_config].child[@c_auto_min_sec + 1].create(_config_sec_num, 1, 711, 274, 10)//.
	
	// 10��������
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec].create_number(_config_sec_num, 1, 806, 299)
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec].set_number((syscom.get_auto_mode_moji_wait * 10 + syscom.get_auto_mode_min_wait) / 1000)
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec].set_number_param(2, 0, 0, 0, 0, 3)
	
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec + 1].create_number(_config_sec_num, 1, 841, 299)
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec + 1].set_number(((syscom.get_auto_mode_moji_wait * 10 + syscom.get_auto_mode_min_wait) % 1000) / 10)
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec + 1].set_number_param(2, 1, 0, 0, 0, 1)
	
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec + 2].create(_config_sec_num, 1, 835, 299, 10)
	
	// ���b�Z�[�E�B���h�E�F�T���v��
	excall.stage[$i].object[@obj_config].child[@c_sample_filter].create(_mwnd_waku, 1, 0, 332)
	excall.stage[$i].object[@obj_config].child[@c_sample_cover].create(_config_base_bg_txt, 1, 0, 0)
	excall.stage[$i].object[@obj_config].child[@c_sample_cover].set_src_clip(1, 0, 327, 1152, 552)
	excall.stage[$i].object[@obj_config].child[@c_sample_msg].create_string("�T���v���\���ł���B", 1, 211, 396)
	excall.stage[$i].object[@obj_config].child[@c_sample_msg].set_string_param(28, 0, 0, 0, 0, 1, -1)
	
	$update_text_object($i)
	
}



// ==========================================================
// �T�E���h���j���[
// ----------------------------------------------------------
command $sound_menu_disp(property $i){

	@config_last_page = 2

	excall.stage[$i].object[@obj_bg].create(_config_bg_filter, 1)//_rect(0, 0, 1152, 720, 0, 0, 0, 128, 1)

	// �y��
	excall.stage[$i].object[@obj_config].create(_config_base_bg, 1, 0, 90, 0)
	excall.stage[$i].object[@obj_config].child.resize(62)
	
	excall.stage[$i].object[@obj_config].child[@c_txt].create(_config_base_sound_txt, 1, 70, 55)
	excall.stage[$i].object[@obj_config].child[@c_txt].child.resize(1)
	excall.stage[$i].object[@obj_config].child[@c_txt].child[0].create(_config_base_title_config, 1, @title_pos_x, @title_pos_y)
	
	// ���ʐݒ�F�����ݒ�
	excall.stage[$i].object[@obj_config].child[@c_vol_default].create(_config_btn_default, 1, 418, 65)
	excall.stage[$i].object[@obj_config].child[@c_vol_default].set_button(@btn_vol_default, 0, 2, 0)
	
	l[1] = 7
	l[2] = 5
	// �S�̂̃{�����[���Fcursor
	l[0] = 121
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 3].set_button(@btn_vol_all + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 2].create(_config_btn_slider_m, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 1].create(_config_btn_mute, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 1].set_button(@btn_vol_all + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_all].create(_config_btn_test, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_all].set_button(@btn_vol_all, 0, 4, -1)

	// BGM�Fcursor
	l[0] = 173
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 3].set_button(@btn_vol_bgm + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 2].create(_config_btn_slider_m, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 1].create(_config_btn_mute, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 1].set_button(@btn_vol_bgm + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm].create(_config_btn_test, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm].set_button(@btn_vol_bgm, 0, 4, -1)
	
	// fade�Fcursor
	l[0] = 212
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 3].create(_config_btn_slide_icon_s, 1, 0, l[0] + l[2])
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 3].set_button(@btn_vol_fade + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 2].create(_config_btn_slider_s, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
//	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 1].create(_config_btn_mute_s, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 1].create(_config_btn_bgmfade_use, 1, 176, 192)
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 1].set_button(@btn_vol_fade + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_fade].create(_config_btn_test_s, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_fade].set_button(@btn_vol_fade, 0, 4, -1)
	
	// pcm�Fcursor
	l[0] = 260
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 3].set_button(@btn_vol_se + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 2].create(_config_btn_slider_m, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 1].create(_config_btn_mute, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 1].set_button(@btn_vol_se + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_se].create(_config_btn_test, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_se].set_button(@btn_vol_se, 0, 4, -1)
	
	// bgse�Fcursor
	l[0] = 299
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 3].create(_config_btn_slide_icon_s, 1, 0, l[0] + l[2])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 3].set_button(@btn_vol_bgse + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 2].create(_config_btn_slider_s, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 1].create(_config_btn_mute_s, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 1].set_button(@btn_vol_bgse + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse].create(_config_btn_test_s, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse].set_button(@btn_vol_bgse, 0, 4, -1)
	
	// vo�Fcursor
	l[0] = 347
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 3].set_button(@btn_vol_vo + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 2].create(_config_btn_slider_m, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 1].create(_config_btn_mute, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 1].set_button(@btn_vol_vo + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_vo].create(_config_btn_test, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_vo].set_button(@btn_vol_vo, 0, 4, -1)

	// bgv�Fcursor
	l[0] = 386
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 3].create(_config_btn_slide_icon_s, 1, 0, l[0] + l[2])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 3].set_button(@btn_vol_bgv + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 2].create(_config_btn_slider_s, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 1].create(_config_btn_mute_s, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 1].set_button(@btn_vol_bgv + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv].create(_config_btn_test_s, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv].set_button(@btn_vol_bgv, 0, 4, -1)

	// movie�Fcursor
	l[0] = 434
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 3].set_button(@btn_vol_movie + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 2].create(_config_btn_slider_m, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 1].create(_config_btn_mute, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 1].set_button(@btn_vol_movie + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_movie].create(_config_btn_test, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_movie].set_button(@btn_vol_movie, 0, 4, -1)

	// sys�Fcursor
	l[0] = 486
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 3].set_button(@btn_vol_sys + 3, 0, 6, 0)
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 2].create(_config_btn_slider_m, 1, @vol_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 1].create(_config_btn_mute, 1, @vol_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 1].set_button(@btn_vol_sys + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_vol_sys].create(_config_btn_test, 1, @vol_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_vol_sys].set_button(@btn_vol_sys, 0, 4, -1)
	
	// �L�����ʉ����F�����ݒ�
	excall.stage[$i].object[@obj_config].child[@c_chara_default].create(_config_btn_default, 1, 986, 65)
	excall.stage[$i].object[@obj_config].child[@c_chara_default].set_button(@btn_chara_default, 0, 2, 0)
	
	// �L���������F�S��ON
	excall.stage[$i].object[@obj_config].child[@c_chara_all_on].create(_config_btn_all_onoff, 1, 629, 93, 1)
	excall.stage[$i].object[@obj_config].child[@c_chara_all_on].set_button(@btn_chara_all_on, 0, 2, 0)
	
	// off
	excall.stage[$i].object[@obj_config].child[@c_chara_all_off].create(_config_btn_all_onoff, 1, 701, 93, 0)
	excall.stage[$i].object[@obj_config].child[@c_chara_all_off].set_button(@btn_chara_all_off, 0, 2, 0)
	
	// �m�m�Fcursor
	l[0] = 170
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 3].set_button(@btn_chara_nono + 3, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 2].create(_config_btn_slider_m, 1, @chara_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 1].create(_config_btn_mute, 1, @chara_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 1].set_button(@btn_chara_nono + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_chara_nono].create(_config_btn_test, 1, @chara_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_nono].set_button(@btn_chara_nono, 0, 4, -1)

	// �z�Fcursor
	l[0] = 248
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 3].set_button(@btn_chara_rin + 3, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 2].create(_config_btn_slider_m, 1, @chara_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 1].create(_config_btn_mute, 1, @chara_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 1].set_button(@btn_chara_rin + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_chara_rin].create(_config_btn_test, 1, @chara_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_rin].set_button(@btn_chara_rin, 0, 4, -1)
	
	// �ڗ����Fcursor
	l[0] = 326
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 3].set_button(@btn_chara_ruri + 3, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 2].create(_config_btn_slider_m, 1, @chara_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 1].create(_config_btn_mute, 1, @chara_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 1].set_button(@btn_chara_ruri + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri].create(_config_btn_test, 1, @chara_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri].set_button(@btn_chara_ruri, 0, 4, -1)
	
	// �݂邭�Fcursor
	l[0] = 404
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 3].set_button(@btn_chara_milk + 3, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 2].create(_config_btn_slider_m, 1, @chara_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 1].create(_config_btn_mute, 1, @chara_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 1].set_button(@btn_chara_milk + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_chara_milk].create(_config_btn_test, 1, @chara_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_milk].set_button(@btn_chara_milk, 0, 4, -1)

	// ���̑��Fcursor
	l[0] = 448
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 3].create(_config_btn_slide_icon_m, 1, 0, l[0] + l[1])
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 3].set_button(@btn_chara_other + 3, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 3].set_button_pushkeep(1)
	
	// �X���C�_�[
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 2].create(_config_btn_slider_m, 1, @chara_slide_x, l[0], 1)
	
	// ONOFF
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 1].create(_config_btn_mute, 1, @chara_mute_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 1].set_button(@btn_chara_other + 1, 0, 2, 0)
	
	// test
	excall.stage[$i].object[@obj_config].child[@c_chara_other].create(_config_btn_test, 1, @chara_test_x, l[0])
	excall.stage[$i].object[@obj_config].child[@c_chara_other].set_button(@btn_chara_other, 0, 4, -1)

	// �Đ��ݒ�
	excall.stage[$i].object[@obj_config].child[@c_koe_keep].create(_config_btn_koe_keep, 1, 726, 479)
	excall.stage[$i].object[@obj_config].child[@c_koe_keep].set_button(@btn_koe_keep, 0, 2, 0)
	
	$update_sound_object($i)
	
}


// ==========================================================
// �܂܁[
// ----------------------------------------------------------
command $mama_menu_disp(property $i){

	@config_last_page = 3

	excall.stage[$i].object[@obj_bg].create(_config_bg_filter, 1)//_rect(0, 0, 1152, 720, 0, 0, 0, 128, 1)

	excall.stage[$i].object[@obj_config].create(_config_base_bg, 1, 0, 90, 0)
	excall.stage[$i].object[@obj_config].child.resize(9)
	
	excall.stage[$i].object[@obj_config].child[@c_txt].create(_config_base_mama_txt, 1, 70, 55)
	excall.stage[$i].object[@obj_config].child[@c_txt].child.resize(1)
	excall.stage[$i].object[@obj_config].child[@c_txt].child[0].create(_config_base_title_config, 1, @title_pos_x, @title_pos_y)
	
	excall.stage[$i].object[@obj_config].child[@c_mama_use].create(_config_btn_mama_use, 1, 140, 160, @mama_use)
	excall.stage[$i].object[@obj_config].child[@c_mama_use].set_button(@btn_mama_use, 0, 2, 0)
	
	excall.stage[$i].object[@obj_config].child[@c_mama_dummy].create(_config_btn_mama_mode, 1, 167, 207)
	
	excall.stage[$i].object[@obj_config].child[@c_mama_crash].create(_config_btn_mama_mode, 1, 167, 406)
	
	$mama_mode_type($i)
	
	for(l[0] = 0, l[0] < @mama_thum_num, l[0] += 1){
		$mama_thum_update($i)
	}

}

// ==========================================================
// �V�X�e�����j���[�F����
// ----------------------------------------------------------
command $system_menu_decision(property $i){

	l[2] = $i

	// ��ʃ��[�h
	if(l[2] == @btn_window){
		syscom.set_window_mode(0)
		$window_surve
	}
	if(l[2] == @btn_full){
		syscom.set_window_mode(1)
		$window_surve
	}
	if(l[2] == @btn_screen){
		syscom.call_config_window_mode_menu
	}
	// �\�����x
	if(@btn_show_spd_ch <= l[2] && l[2] <= @btn_show_spd_ch + 2){	// �L�����\��
		@show_spd_ch = $show_spd(l[2], @c_show_ch, @btn_show_spd_ch)
	}
	if(@btn_show_spd_ev <= l[2] && l[2] <= @btn_show_spd_ev + 2){	// �C�x���g�\��
		@show_spd_ev = $show_spd(l[2], @c_show_ev, @btn_show_spd_ev)
	}
	if(@btn_show_spd_sys <= l[2] && l[2] <= @btn_show_spd_sys + 2){	// �V�X�e���\��
		@show_spd_sys = $show_spd(l[2], @c_show_sys, @btn_show_spd_sys)
		l[30] = front.mwnd[0].get_default_open_anime_time // 2
		front.mwnd[0].set_open_anime_time(l[30] * (2 - @show_spd_sys))
		front.mwnd[0].set_close_anime_time(l[30] * (2 - @show_spd_sys))
	}
	
	// ���b�Z�[�W�X�L�b�v
	if(l[2] == @btn_msg_skip_already){	// ���Ǖ��͂̂�
		syscom.set_skip_unread_message_onoff(0)
		excall.front.object[@obj_config].child[@c_msg_skip].patno = 1
		excall.front.object[@obj_config].child[@c_msg_skip].clear_button
		excall.front.object[@obj_config].child[@c_msg_skip + 1].patno = 2
		excall.front.object[@obj_config].child[@c_msg_skip + 1].set_button(@btn_msg_skip_unread, 0, 2, 0)
	}
	if(l[2] == @btn_msg_skip_unread){
		syscom.set_skip_unread_message_onoff(1)
		excall.front.object[@obj_config].child[@c_msg_skip].patno = 0
		excall.front.object[@obj_config].child[@c_msg_skip].set_button(@btn_msg_skip_already, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_msg_skip + 1].patno = 3
		excall.front.object[@obj_config].child[@c_msg_skip + 1].clear_button
	}
	
	// �I�[�g�Z�[�u
	if(l[2] == @btn_auto_save_use){	// �g�p����
		@autosave_use = 1
		excall.front.object[@obj_config].child[@c_auto_save + 1].patno = 1
		excall.front.object[@obj_config].child[@c_auto_save + 1].clear_button
		excall.front.object[@obj_config].child[@c_auto_save].patno = 2
		excall.front.object[@obj_config].child[@c_auto_save].set_button(@btn_auto_save_dis, 0, 2, 0)
	}
	if(l[2] == @btn_auto_save_dis){
		@autosave_use = 0
		excall.front.object[@obj_config].child[@c_auto_save + 1].patno = 0
		excall.front.object[@obj_config].child[@c_auto_save + 1].set_button(@btn_auto_save_use, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_auto_save].patno = 3
		excall.front.object[@obj_config].child[@c_auto_save].clear_button
	}
	
	// �I���ςݑI����
	if(l[2] == @btn_selected_change){	// �F��ς���
		@selected_choice = 1		// x choice o option�ł����
		excall.front.object[@obj_config].child[@c_selected + 1].patno = 1
		excall.front.object[@obj_config].child[@c_selected + 1].clear_button
		excall.front.object[@obj_config].child[@c_selected].patno = 2
		excall.front.object[@obj_config].child[@c_selected].set_button(@btn_selected_steady)
	}
	if(l[2] == @btn_selected_steady){	// ���̂܂�
		@selected_choice = 0
		excall.front.object[@obj_config].child[@c_selected + 1].patno = 0
		excall.front.object[@obj_config].child[@c_selected + 1].set_button(@btn_selected_change, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_selected].patno = 3
		excall.front.object[@obj_config].child[@c_selected].clear_button
	}
	
	if(l[2] == @btn_spot_fixed_on){	// �I�����Œ�g�p
		@spot_fixed_onoff = 1
		excall.front.object[@obj_config].child[@c_fixed].patno = 1
		excall.front.object[@obj_config].child[@c_fixed].clear_button
		excall.front.object[@obj_config].child[@c_fixed + 1].patno = 2
		excall.front.object[@obj_config].child[@c_fixed + 1].set_button(@btn_spot_fixed_off, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_spot + 1 - @spot_fixed_creampie].set_button(@btn_spot_fixed_place + 1 - @spot_fixed_creampie, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_spot + 2 + 1 - @spot_fixed_bukkake].set_button(@btn_spot_fixed_place + 2 + 1 - @spot_fixed_bukkake, 0, 2, 0)
		for(l[0] = 0, l[0] < 4, l[0] += 1){
			excall.front.object[@obj_config].child[@c_spot + l[0]].dark = 0
		}
	}
	if(l[2] == @btn_spot_fixed_off){	// �I�����Œ�s�g�p
		@spot_fixed_onoff = 0
		excall.front.object[@obj_config].child[@c_fixed].patno = 0
		excall.front.object[@obj_config].child[@c_fixed].set_button(@btn_spot_fixed_on, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_fixed + 1].patno = 3
		excall.front.object[@obj_config].child[@c_fixed + 1].clear_button
		for(l[0] = 0, l[0] < 4, l[0] += 1){
			excall.front.object[@obj_config].child[@c_spot + l[0]].clear_button
			excall.front.object[@obj_config].child[@c_spot + l[0]].dark = 48
		}
	}
	if(l[2] == @btn_spot_fixed_creampie || l[2] == @btn_spot_fixed_creampie + 1){	// �Ȃ�����
		@spot_fixed_creampie = l[2] - @btn_spot_fixed_creampie
		excall.front.object[@obj_config].child[@c_spot + @spot_fixed_creampie].patno += 1
		excall.front.object[@obj_config].child[@c_spot + 1 - @spot_fixed_creampie].patno -= 1
		excall.front.object[@obj_config].child[@c_spot + @spot_fixed_creampie].clear_button
		excall.front.object[@obj_config].child[@c_spot + 1 - @spot_fixed_creampie].set_button(@btn_spot_fixed_creampie + 1 - @spot_fixed_creampie, 0, 2, 0)
	}
	if(l[2] == @btn_spot_fixed_bukkake || l[2] == @btn_spot_fixed_bukkake + 1){	// ��
		@spot_fixed_bukkake = l[2] - @btn_spot_fixed_bukkake
		excall.front.object[@obj_config].child[@c_spot + 2 + @spot_fixed_bukkake].patno += 1
		excall.front.object[@obj_config].child[@c_spot + 2 + 1 - @spot_fixed_bukkake].patno -= 1
		excall.front.object[@obj_config].child[@c_spot + 2 + @spot_fixed_bukkake].clear_button
		excall.front.object[@obj_config].child[@c_spot + 2 + 1 - @spot_fixed_bukkake].set_button(@btn_spot_fixed_bukkake + 1 - @spot_fixed_bukkake, 0, 2, 0)
	}	
	// �E�N���b�N����
	if(@btn_rclick_start <= l[2] && l[2] <= @btn_rclick_end){
		for(l[0] = 0, l[0] < @btn_rclick_end - @btn_rclick_start + 1, l[0] += 1){
			excall.front.object[@obj_config].child[@c_rclick + l[0]].patno = 2 * l[0]
			excall.front.object[@obj_config].child[@c_rclick + l[0]].set_button(@btn_rclick_start + l[0])
		}
		@rclick_work = l[2] - @btn_rclick_start
		excall.front.object[@obj_config].child[@c_rclick + @rclick_work].patno += 1
		excall.front.object[@obj_config].child[@c_rclick + @rclick_work].clear_button
	}

	// �m�F���b�Z�[�W�̗L��
	if(l[2] >= @btn_confirm_start && @btn_confirm_end >= l[2]){
		l[10] = l[2] - @btn_confirm_start
		@confirm_start(l[10]) = 1 -@confirm_start(l[10])
		excall.front.object[@obj_config].child[@c_confirm + l[10]].patno = l[10] * 2 + @confirm_start(l[10])
	}

	// ���̑��̐ݒ�
	if(l[2] == @btn_other_mouse){	// �}�E�X�z�C�[���́B
			syscom.set_wheel_next_message_onoff(1 - syscom.get_wheel_next_message_onoff)
			excall.front.object[@obj_config].child[@c_other].patno = syscom.get_wheel_next_message_onoff
	}
	if(l[2] == @btn_other_priority){	// �v���O�����̗D�揇�ʂ́B
			syscom.set_sleep_onoff(1 - syscom.get_sleep_onoff)
			excall.front.object[@obj_config].child[@c_other + 1].patno = syscom.get_sleep_onoff
	}
	if(l[2] == @btn_other_movie){	// ���[�r�[�ݒ�
		syscom.call_config_movie_menu	// �_�C�A���O���Ăяo��
	}
	if(l[2] == @btn_other_cursor){
		syscom.set_mouse_cursor_hide_onoff(1 - syscom.get_mouse_cursor_hide_onoff)
		excall.front.object[@obj_config].child[@c_other + 2].patno = syscom.get_mouse_cursor_hide_onoff
	}
}

// ==========================================================
// �e�L�X�g���j���[�F����
// ----------------------------------------------------------
command $text_menu_decision(property $i, property $j){

	l[1] = $i
	l[2] = $j
	
	if($push_btn_no != l[1]){
		$push_btn_no = l[1]
		$push_mouse_x = mouse.pos_x
		
		if(l[1] == @btn_msg_spd_cursor){
			$push_btn_x = excall.front.object[@obj_config].child[@c_msg_spd_cursor].x
		}
		if(l[1] == @btn_filter_cursor){
			$push_btn_x = excall.front.object[@obj_config].child[@c_filter_cursor].x
		}
		if(l[1] == @btn_auto_moji_cursor){
			$push_btn_x = excall.front.object[@obj_config].child[@c_auto_moji_cursor].x
		}
		if(l[1] == @btn_auto_min_cursor){
			$push_btn_x = excall.front.object[@obj_config].child[@c_auto_min_cursor].x
		}
	}
	
	if(l[1] == @btn_msg_spd_cursor){
		excall.front.object[@obj_config].child[@c_msg_spd_cursor].x = $push_btn_x + mouse.pos_x - $push_mouse_x
		$update_text_config
		$update_text_object(1)
	}
	if(l[1] == @btn_filter_cursor){
		excall.front.object[@obj_config].child[@c_filter_cursor].x = $push_btn_x + mouse.pos_x - $push_mouse_x
		$update_text_config
		$update_text_object(1)
	}
	if(l[1] == @btn_auto_moji_cursor){
		excall.front.object[@obj_config].child[@c_auto_moji_cursor].x = $push_btn_x + mouse.pos_x - $push_mouse_x
		$update_text_config
		$update_text_object(1)
	}
	if(l[1] == @btn_auto_min_cursor){
		excall.front.object[@obj_config].child[@c_auto_min_cursor].x = $push_btn_x + mouse.pos_x - $push_mouse_x
		$update_text_config
		$update_text_object(1)
	}
	
	if(l[2] == @btn_msg_spd_default){
		syscom.set_message_speed_default
		syscom.set_message_nowait(0)
		$update_text_object(1)
	}
	if(l[2] == @btn_msg_spd_nowait){
		syscom.set_message_nowait(1 - syscom.get_message_nowait)
		$update_text_object(1)
	}
	if(l[2] == @btn_filter_default){
		syscom.set_filter_color_a_default
		$update_text_object(1)
	}
	if(l[2] == @btn_font_set){
		syscom.call_config_font_menu
	}
	if(l[2] == @btn_auto_default){
		syscom.set_auto_mode_onoff_flag(0)
		syscom.set_auto_mode_moji_wait_default
		syscom.set_auto_mode_min_wait_default
		$update_text_object(1)
	}
	if(l[2] == @btn_auto_onoff){
		syscom.set_auto_mode_onoff_flag(1 - syscom.get_auto_mode_onoff_flag)
		$update_text_object(1)
	}
	
	$update_mwnd_sample(1)
}

// ==========================================================
// �T�E���h���j���[�F����
// ----------------------------------------------------------
command $sound_menu_decision(property $i, property $j){

	l[1] = $i
	l[2] = $j
	
	if ($push_btn_no != l[1]){
		$push_btn_no = l[1]
		$push_mouse_x = mouse.pos_x		// �������Ƃ��̃}�E�XX���W

	// �����������X���C�_�[�������ꍇ�A�I�u�W�F�N�g�̈ʒu���L��

		if(l[1] == @btn_vol_all + 3){		// �X���C�_�[�F�S�̂̃{�����[��
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_all + 3].x
		}
		if(l[1] == @btn_vol_bgm + 3){		// �X���C�_�[�F�a�f�l
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_bgm + 3].x
		}
		if(l[1] == @btn_vol_fade + 3){	// �X���C�_�[�F�t�F�[�h
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_fade + 3].x
		}
		if(l[1] == @btn_vol_se + 3){		// �X���C�_�[�F���ʉ�
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_se + 3].x
		}
		if(l[1] == @btn_vol_bgse + 3){	// �X���C�_�[�F�g���ʉ�
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_bgse + 3].x
		}
		if(l[1] == @btn_vol_vo + 3){		// �X���C�_�[�F�L�����N�^����
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_vo + 3].x
		}
		if(l[1] == @btn_vol_bgv + 3){		// �X���C�_�[�F��������
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_bgv + 3].x
		}
		if(l[1] == @btn_vol_movie + 3){	// �X���C�_�[�F���[�r�[����
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_movie + 3].x
		}
		if(l[1] == @btn_vol_sys + 3){		// �X���C�_�[�F�V�X�e����
			$push_btn_x = excall.front.object[@obj_config].child[@c_vol_sys + 3].x
		}
		if(l[1] == @btn_chara_nono + 3){ // �X���C�_�[�F�m�m
			$push_btn_x = excall.front.object[@obj_config].child[@c_chara_nono + 3].x
		}
		if(l[1] == @btn_chara_rin + 3){		// �X���C�_�[�F�z
			$push_btn_x = excall.front.object[@obj_config].child[@c_chara_rin + 3].x
		}
		if(l[1] == @btn_chara_ruri + 3){		// �X���C�_�[�F�ڗ����
			$push_btn_x = excall.front.object[@obj_config].child[@c_chara_ruri + 3].x
		}
		if(l[1] == @btn_chara_milk + 3){		// �X���C�_�[�F�݂邭
			$push_btn_x = excall.front.object[@obj_config].child[@c_chara_milk + 3].x
		}
		if(l[1] == @btn_chara_other + 3){	// �X���C�_�[�F���̑�����
			$push_btn_x = excall.front.object[@obj_config].child[@c_chara_other + 3].x
		}
	}
	
	// �X���C�_�[�������Ă���Œ��A�}�E�X�̍��W�ɏ]���ē�����
	if(l[1] == @btn_vol_all + 3){			// ���ʐݒ�
		$object_sound_move(@c_vol_all)
	}
	if(l[1] == @btn_vol_bgm + 3){
		$object_sound_move(@c_vol_bgm)
	}
	if(l[1] == @btn_vol_fade + 3){
		$object_sound_move(@c_vol_fade)
	}
	if(l[1] == @btn_vol_se + 3){
		$object_sound_move(@c_vol_se)
	}
	if(l[1] == @btn_vol_bgse + 3){
		$object_sound_move(@c_vol_bgse)
	}
	if(l[1] == @btn_vol_vo + 3){
		$object_sound_move(@c_vol_vo)
	}
	if(l[1] == @btn_vol_bgv + 3){
		$object_sound_move(@c_vol_bgv)
	}
	if(l[1] == @btn_vol_movie + 3){
		$object_sound_move(@c_vol_movie)
	}
	if(l[1] == @btn_vol_sys + 3){
		$object_sound_move(@c_vol_sys)
	}
	if(l[1] == @btn_chara_nono + 3){		// �L�����N�^����
		$object_sound_move(@c_chara_nono)
	}
	if(l[1] == @btn_chara_rin + 3){
		$object_sound_move(@c_chara_rin)
	}
	if(l[1] == @btn_chara_ruri + 3){
		$object_sound_move(@c_chara_ruri)
	}
	if(l[1] == @btn_chara_milk + 3){
		$object_sound_move(@c_chara_milk)
	}
	if(l[1] == @btn_chara_other + 3){
		$object_sound_move(@c_chara_other)
	}
	
	// �{�^�������肵���ꍇ�̏���
	if(l[2] == @btn_vol_default){		// ���ʐݒ�F�����ݒ�ɖ߂�
		syscom.set_all_volume_default	// �e�퉹�ʂ̏����ݒ�l
		syscom.set_bgm_volume_default
		syscom.set_bgmfade_volume_default
		syscom.set_pcm_volume_default
		//syscom.set_sound_volume(@type_bgse, @volume_default)
		syscom.set_sound_volume_default(@type_bgse)
		syscom.set_koe_volume_default
		//syscom.set_sound_volume(@type_bgv, @volume_default)
		syscom.set_sound_volume_default(@type_bgv)
		syscom.set_mov_volume_default
		syscom.set_se_volume_default
		
		syscom.set_all_onoff_default	// �g�p�ݒ�
		syscom.set_bgm_onoff_default
		syscom.set_bgmfade_onoff_default
		syscom.set_pcm_onoff_default
		syscom.set_sound_onoff_default(@type_bgse)
		syscom.set_koe_onoff_default
		syscom.set_sound_onoff_default(@type_bgv)
		syscom.set_mov_onoff_default
		syscom.set_se_onoff_default
	}
	
	if(l[2] == @btn_vol_all + 1){		// ���ʐݒ�F�S�́F�~���[�g
		syscom.set_all_onoff(1 - syscom.get_all_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_all){		// �S�́F�e�X�g
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = -1)
	}
	if(l[2] == @btn_vol_bgm + 1){		// �a�f�l
		syscom.set_bgm_onoff(1 - syscom.get_bgm_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_bgm){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = 0)
	}
	if(l[2] == @btn_vol_fade + 1){	// �a�f�l�t�F�[�h
		syscom.set_bgmfade_onoff(1 - syscom.get_bgmfade_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_fade){
		pcmch[@pcmch_test].set_volume(syscom.get_bgmfade_volume)
		exkoe(000100731,000)
	}
	if(l[2] == @btn_vol_se + 1){		// ���ʉ�
		syscom.set_pcm_onoff(1 - syscom.get_pcm_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_se){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = 2)
	}
	if(l[2] == @btn_vol_bgse + 1){	// �o�b�N�O���E���h�r�d
		syscom.set_sound_onoff(@type_bgse, 1 - syscom.get_sound_onoff(@type_bgse))
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_bgse){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = @type_bgse)
	}
	if(l[2] == @btn_vol_vo + 1){		// �L��������
		syscom.set_koe_onoff(1 - syscom.get_koe_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_vo){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = 1)
	}
	if(l[2] == @btn_vol_bgv + 1){		// ��������
		syscom.set_sound_onoff(@type_bgv, 1 - syscom.get_sound_onoff(@type_bgv))
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_bgv){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = @type_bgv)
	}
	if(l[2] == @btn_vol_movie + 1){	// ���[�r�[����
		syscom.set_mov_onoff(1 -syscom.get_mov_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_movie){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = 4)
	}
	if(l[2] == @btn_vol_sys + 1){		// �V�X�e����
		syscom.set_se_onoff(1 - syscom.get_se_onoff)
		$update_sound_object(1)
	}
	if(l[2] == @btn_vol_sys){
		pcmch[@pcmch_test].set_volume_max
		pcmch[@pcmch_test].play(file_name = "cutaway_korokoro", volume_type = 3)
	}
	
	if(l[2] == @btn_chara_default){		// �L�����N�^�����F�����ݒ�ɖ߂�
		syscom.set_koe_dont_stop_onoff_default
		syscom.set_charakoe_onoff_default(00)	// ��
		syscom.set_charakoe_onoff_default(01)	// ��i
		syscom.set_charakoe_onoff_default(02)	// �^�}��
		syscom.set_charakoe_onoff_default(03)	// �T�[�j��
		syscom.set_charakoe_onoff_default(04)	// ���X
		syscom.set_charakoe_onoff_default(05)	// A
		syscom.set_charakoe_onoff_default(06)	// B
		syscom.set_charakoe_onoff_default(07)	// C
		syscom.set_charakoe_onoff_default(08)
		syscom.set_charakoe_volume_default(00)	// ��
		syscom.set_charakoe_volume_default(01)	// ��i
		syscom.set_charakoe_volume_default(02)	// �^�}��
		syscom.set_charakoe_volume_default(03)	// �T�[�j��
		syscom.set_charakoe_volume_default(04)	// ���X
		syscom.set_charakoe_volume_default(05)	// A
		syscom.set_charakoe_volume_default(06)	// B
		syscom.set_charakoe_volume_default(07)	// C
		syscom.set_charakoe_volume_default(08)
	}
	if(l[2] == @btn_chara_all_on){		// �L�����N�^�����FON
		syscom.set_charakoe_onoff(00, 1)	// ��
		syscom.set_charakoe_onoff(01, 1)	// ��i
		syscom.set_charakoe_onoff(02, 1)	// �^�}��
		syscom.set_charakoe_onoff(03, 1)	// �T�[�j��
		syscom.set_charakoe_onoff(04, 1)	// ���X
		syscom.set_charakoe_onoff(05, 1)	// A
		syscom.set_charakoe_onoff(06, 1)	// B
		syscom.set_charakoe_onoff(07, 1)	// C
		syscom.set_charakoe_onoff(08, 1)
	}
	if(l[2] == @btn_chara_all_off){		// �L�����N�^�����Foff
		syscom.set_charakoe_onoff(00, 0)	// ��
		syscom.set_charakoe_onoff(01, 0)	// ��i
		syscom.set_charakoe_onoff(02, 0)	// �^�}��
		syscom.set_charakoe_onoff(03, 0)	// �T�[�j��
		syscom.set_charakoe_onoff(04, 0)	// ���X
		syscom.set_charakoe_onoff(05, 0)	// A
		syscom.set_charakoe_onoff(06, 0)	// B
		syscom.set_charakoe_onoff(07, 0)	// C
		syscom.set_charakoe_onoff(08, 0)
	}
		
//KOE(000102851,000)�y�m�m�z
//KOE(000100196,001)�y�ڗ����z
//KOE(000102057,002)�y�z�z
//KOE(000102305,003)�y�݂邭�z

	if(l[2] == @btn_chara_nono + 1){	// �L�����N�^�����F�m�m
		syscom.set_charakoe_onoff(0, 1 - syscom.get_charakoe_onoff(0))
		$update_sound_object(1)
	}
	if(l[2] == @btn_chara_nono){
		exKOE(000102851,000)
	}
	if(l[2] == @btn_chara_rin + 1){	// �L�����N�^�����F�z
		syscom.set_charakoe_onoff(2, 1 - syscom.get_charakoe_onoff(2))
		$update_sound_object(1)
	}
	if(l[2] == @btn_chara_rin){
		exKOE(000102057,002)
	}
	if(l[2] == @btn_chara_ruri + 1){	// �L�����N�^�����F�ڗ����
		syscom.set_charakoe_onoff(1, 1 - syscom.get_charakoe_onoff(1))
		$update_sound_object(1)
	}
	if(l[2] == @btn_chara_ruri){
		exKOE(000100196,001)
	}
	if(l[2] == @btn_chara_milk + 1){	// �L�����N�^�����F�݂邭
		syscom.set_charakoe_onoff(3, 1 - syscom.get_charakoe_onoff(3))
		$update_sound_object(1)
	}
	if(l[2] == @btn_chara_milk){
		exKOE(000102305,003)
	}
	
	if(l[2] == @btn_chara_other + 1){	// �L�����N�^�����F���̑�
		syscom.set_charakoe_onoff(4, 1 - syscom.get_charakoe_onoff(4))
		syscom.set_charakoe_onoff(5, 1 - syscom.get_charakoe_onoff(5))
		syscom.set_charakoe_onoff(6, 1 - syscom.get_charakoe_onoff(6))
		syscom.set_charakoe_onoff(7, 1 - syscom.get_charakoe_onoff(7))
		syscom.set_charakoe_onoff(8, 1 - syscom.get_charakoe_onoff(8))
		$update_sound_object(1)
	}
	if(l[2] == @btn_chara_other){
		exKOE(000100986,005)
	}
	
	if(l[2] == @btn_koe_keep){			// �����Đ����Ɏ��̕��́E�|
		syscom.set_koe_dont_stop_onoff(1 - syscom.get_koe_dont_stop_onoff)
		$update_sound_object(1)
	}

}


// ==========================================================
// �܂܁F����
// ----------------------------------------------------------
command $mama_menu_decision(property $i){

	l[2] = $i
	
	// �{�^�������肵���ꍇ�̏���
	if(l[2] == @btn_mama_use){		// ���[�h�̗L���E����
		@mama_use = 1 - @mama_use
		excall.front.object[@obj_config].child[@c_mama_use].patno = @mama_use
		if(@mama_use){
			frame_action_ch[@frame_action_ch_no_mama_key].start(-1, "$mama_watch")
		}
		else{
			frame_action_ch[@frame_action_ch_no_mama_key].end
		}
	}
	if(l[2] == @btn_mama_dummy){			// �_�~�[���[�h
		@mama_type = 0
		$mama_mode_type(1)
	}
	if(l[2] == @btn_mama_crash){			// �����I��
		@mama_type = 1
		$mama_mode_type(1)
	}
	if(@btn_mama_thum_start <= l[2] && l[2] < @btn_mama_thum_start + @mama_thum_num){
		@mama_dummy = l[2] - @btn_mama_thum_start
		$mama_thum_update(1)
	}
}
// ==========================================================
// �E�B���h�E���[�h�̊Ď��ƁA�ق��̂��̂�
// ----------------------------------------------------------
command $window_surve{

	if(syscom.get_window_mode == 0){
		excall.front.object[@obj_config].child[@c_window].patno = 1
		excall.front.object[@obj_config].child[@c_window].clear_button
		excall.front.object[@obj_config].child[@c_full].patno = 2
		excall.front.object[@obj_config].child[@c_full].set_button(@btn_full, 0, 2, 0)
	}
	else{
		excall.front.object[@obj_config].child[@c_window].patno = 0
		excall.front.object[@obj_config].child[@c_window].set_button(@btn_window, 0, 2, 0)
		excall.front.object[@obj_config].child[@c_full].patno = 3
		excall.front.object[@obj_config].child[@c_full].clear_button
	}
	
	for(l[0] = 0, l[0] < 8, l[0] += 1){
		excall.front.object[@obj_config].child[@c_confirm + l[0]].patno = l[0] * 2 + @confirm_start(l[0])
	}	

}

// ==========================================================
// ���ݒ肩��I�u�W�F�N�g�𔽉f�F�e�L�X�g
// ----------------------------------------------------------
command $update_text_object(property $i){

	// �m�[�E�F�C�g�`�F�b�N�{�b�N�X
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_nowait].patno = syscom.get_message_nowait

	// �������x�F�X���C�_�[�ʒu
	excall.stage[$i].object[@obj_config].child[@c_msg_spd_cursor].x = math.timetable(syscom.get_message_speed, 0, @slide_spd_pos + @slide_width_w, [0, 100, @slide_spd_pos])

	// �E�B���h�E�w�i�F�X���C�_�[�ʒu
	excall.stage[$i].object[@obj_config].child[@c_filter_cursor].x = math.timetable(syscom.get_filter_color_a, 0, @slide_spd_pos + @slide_width_w, [0, 255, @slide_spd_pos])
	
	// �I�[�g���[�h�`�F�b�N�{�b�N�X
	excall.stage[$i].object[@obj_config].child[@c_auto_onoff].patno = syscom.get_auto_mode_onoff_flag

	// �������ԁF�X���C�_�[�ʒu
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_cursor].x = math.timetable(syscom.get_auto_mode_moji_wait, 0, @slide_moji_pos + @slide_width_t, [0, 500, @slide_moji_pos])

	// �ŏ����ԁF�X���C�_�[�ʒu
	excall.stage[$i].object[@obj_config].child[@c_auto_min_cursor].x = math.timetable(syscom.get_auto_mode_min_wait, 0, @slide_moji_pos + @slide_width_t, [0, 5000, @slide_moji_pos])

	// �P�O�����\���̕b��
	excall.stage[$i].object[@obj_config].child[@c_auto_moji_sec + 2].set_number(syscom.get_auto_mode_moji_wait / 10)

	// �ŏ����Ԃ̕b��
	excall.stage[$i].object[@obj_config].child[@c_auto_min_sec].set_number(syscom.get_auto_mode_min_wait / 100)

	// �����𓥂܂����b��
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec].set_number((syscom.get_auto_mode_moji_wait * 10 + syscom.get_auto_mode_min_wait) / 1000)
	excall.stage[$i].object[@obj_config].child[@c_auto_10moji_sec + 1].set_number(((syscom.get_auto_mode_moji_wait * 10 + syscom.get_auto_mode_min_wait) % 1000) / 10)

	// �t�B���^�[�����x
	excall.stage[$i].object[@obj_config].child[@c_sample_filter].tr = syscom.get_filter_color_a
	
	// �N���[�X�{�^��
//	excall.stage[$i].object[@obj_config].child[@c_sample_close].tr = math.timetable(syscom.get_filter_color_a, 0, @mwnd_close_tr_min, [0, 255, 255])

}

// ==========================================================
// �X���C�_�[�̈ʒu�������ݒ�
// ----------------------------------------------------------
// �X���C�_�[�̕���142px->(443-271)-(33+1)=139-1px�B�A�C�R���͍����A�����ɒ�������_
command $update_text_config(){

//	���݁A�C���A�J�n�l���J�n�A�I���A�I���l
	syscom.set_message_speed(math.timetable(excall.front.object[@obj_config].child[@c_msg_spd_cursor].x, 0, 100, [@slide_spd_pos, @slide_spd_pos + @slide_width_w, 0]))
	
	syscom.set_filter_color_a(math.timetable(excall.front.object[@obj_config].child[@c_filter_cursor].x, 0, 255, [@slide_spd_pos, @slide_spd_pos + @slide_width_w, 0]))
	
	syscom.set_auto_mode_moji_wait(math.timetable(excall.front.object[@obj_config].child[@c_auto_moji_cursor].x, 0, 500, [@slide_moji_pos, @slide_moji_pos + @slide_width_t, 0]))
	
	syscom.set_auto_mode_min_wait(math.timetable(excall.front.object[@obj_config].child[@c_auto_min_cursor].x, 0, 5000, [@slide_moji_pos, @slide_moji_pos + @slide_width_t, 0]))
	
}

// ==========================================================
// �\�����x�ύX�A�ĕ`�ʃ��[�`��
// ----------------------------------------------------------
command $show_spd(property $btn_no, property $obj, property $btn){

	property $flag

	for(l[0] = 0, l[0] < 3, l[0] += 1){ // ���Ă��I���A�I���\��
		excall.front.object[@obj_config].child[$obj + l[0]].patno = 2 * l[0]
		excall.front.object[@obj_config].child[$obj + l[0]].set_button($btn + l[0], 0, 2, 0)
	}
	$flag = $btn_no - $btn	// �t���O�l�̎擾
	excall.front.object[@obj_config].child[$obj + $flag].patno += 1	// �Y���ӏ���I�����
	excall.front.object[@obj_config].child[$obj + $flag].clear_button	// �I��s��

	return($flag)	// �t���O�l��Ԃ��ďI���
}

// ==========================================================
// ���b�Z�[�W�E�B���h�E�̃T���v��
// ----------------------------------------------------------
// �I�[�g���[�h�𓥂܂����������ׂ����ǂ����B
command $update_mwnd_sample(property $i)
{
	k[0] = "������̓T���v���\���ł��B"	// �T���v���ɕ\�����镶����
	l[0] = k[0].cnt								// �T���v���ɕ\�����镶����

	// �����S�Ă�\������̂ɕK�v�Ȏ��Ԃ����߂�
	l[1] = syscom.get_message_speed * l[0] + 500	// +500: �Ō��500�ؕb�قǑ҂�

	// �������\������΂����̂������߂�
	if (syscom.get_message_speed == 0 || syscom.get_message_nowait == 1)	{
		l[2] = l[0]		// �҂����Ԃ��O�̏ꍇ�͑S�ĕ\��
	}
	else	{
		l[2] = excall.counter[0].get % l[1]
		l[2] = l[2] / syscom.get_message_speed
		l[2] = math.min(l[2], l[0])
	}

	// ���ۂɃT���v���ɕ\�����镶����
	k[1] = k[0].left(l[2])

	// �I�u�W�F�N�g�ɕ������ݒ肷��
	excall.stage[$i].object[@obj_config].child[@c_sample_msg].set_string(k[1])
}

// =========================================================
command $object_sound_move(property $obj){

	excall.front.object[@obj_config].child[$obj + 3].x = $push_btn_x + mouse.pos_x - $push_mouse_x
	$update_sound_config
	$update_sound_object(1)

}
// =========================================================
// �X���C�_�[�̈ʒu����A����ݒ�
// =========================================================
command $update_sound_config(){
// �X���C�_�[�̕���142px�B�A�C�R���͒�������_

//											���݁A�C���A�J�n�l���J�n�A�I���A�I���l
	syscom.set_all_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_all + 3].x, 0, 0, [@slide_vol_pos, @slide_vol_pos + @slide_width, 255]))

	syscom.set_bgm_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_bgm + 3].x , 0, 0, [@slide_vol_pos, @slide_vol_pos + @slide_width, 255]))
//BGM FADE
	syscom.set_bgmfade_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_fade + 3].x, 0, 0, [@slide_vol_pos_s, @slide_vol_pos_s + @slide_width_s, 255]))

	syscom.set_pcm_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_se + 3].x, 0, 0, [@slide_vol_pos, @slide_vol_pos + @slide_width, 255]))
//BGSE
	syscom.set_sound_volume(@type_bgse, math.timetable(excall.front.object[@obj_config].child[@c_vol_bgse + 3].x, 0, 0, [@slide_vol_pos_s, @slide_vol_pos_s + @slide_width_s, 255]))

	syscom.set_koe_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_vo + 3].x, 0, 0, [@slide_vol_pos, @slide_vol_pos + @slide_width, 255]))
// BGV
	syscom.set_sound_volume(@type_bgv, math.timetable(excall.front.object[@obj_config].child[@c_vol_bgv + 3].x, 0, 0, [@slide_vol_pos_s, @slide_vol_pos_s + @slide_width_s, 255]))

	syscom.set_mov_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_movie + 3].x, 0, 0, [@slide_vol_pos, @slide_vol_pos + @slide_width, 255]))

	syscom.set_se_volume(math.timetable(excall.front.object[@obj_config].child[@c_vol_sys + 3].x, 0, 0, [@slide_vol_pos, @slide_vol_pos + @slide_width, 255]))

	syscom.set_charakoe_volume(0, math.timetable(excall.front.object[@obj_config].child[@c_chara_nono + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))

	syscom.set_charakoe_volume(2, math.timetable(excall.front.object[@obj_config].child[@c_chara_rin + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))

	syscom.set_charakoe_volume(1, math.timetable(excall.front.object[@obj_config].child[@c_chara_ruri + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))

	syscom.set_charakoe_volume(3, math.timetable(excall.front.object[@obj_config].child[@c_chara_milk + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))

	syscom.set_charakoe_volume(4, math.timetable(excall.front.object[@obj_config].child[@c_chara_other + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))
	syscom.set_charakoe_volume(5, math.timetable(excall.front.object[@obj_config].child[@c_chara_other + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))
	syscom.set_charakoe_volume(6, math.timetable(excall.front.object[@obj_config].child[@c_chara_other + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))
	syscom.set_charakoe_volume(7, math.timetable(excall.front.object[@obj_config].child[@c_chara_other + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))
	syscom.set_charakoe_volume(8, math.timetable(excall.front.object[@obj_config].child[@c_chara_other + 3].x, 0, 0, [@slide_chara_pos, @slide_chara_pos + @slide_width, 255]))



}

// =========================================================
// ���ݒ肩��A�I�u�W�F�N�g��ݒ�
// =========================================================
command $update_sound_object(property $i){

	// �S��
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 3].x = math.timetable(syscom.get_all_volume, 0, @slide_vol_pos, [0, 255, @slide_vol_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_vol_all + 1].patno = syscom.get_all_onoff

	// �a�f�l
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 3].x = math.timetable(syscom.get_bgm_volume, 0, @slide_vol_pos, [0, 255, @slide_vol_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgm + 1].patno = syscom.get_bgm_onoff

	// �a�f�l�t�F�[�h
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 3].x = math.timetable(syscom.get_bgmfade_volume, 0, @slide_vol_pos_s, [0, 255, @slide_vol_pos_s + @slide_width_s])
	excall.stage[$i].object[@obj_config].child[@c_vol_fade + 1].patno = syscom.get_bgmfade_onoff

	// ���ʉ�
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 3].x = math.timetable(syscom.get_pcm_volume, 0, @slide_vol_pos, [0, 255, @slide_vol_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_vol_se + 1].patno = syscom.get_pcm_onoff

	// �a�f�r�d
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 3].x = math.timetable(syscom.get_sound_volume(@type_bgse), 0, @slide_vol_pos_s, [0, 255, @slide_vol_pos_s + @slide_width_s])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgse + 1].patno = syscom.get_sound_onoff(@type_bgse)

	// ��
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 3].x = math.timetable(syscom.get_koe_volume, 0, @slide_vol_pos, [0, 255, @slide_vol_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_vol_vo + 1].patno = syscom.get_koe_onoff

	// ��������
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 3].x = math.timetable(syscom.get_sound_volume(@type_bgv), 0, @slide_vol_pos_s, [0, 255, @slide_vol_pos_s + @slide_width_s])
	excall.stage[$i].object[@obj_config].child[@c_vol_bgv + 1].patno =syscom.get_sound_onoff(@type_bgv)

	// ���[�r�[
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 3].x = math.timetable(syscom.get_mov_volume, 0, @slide_vol_pos, [0, 255, @slide_vol_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_vol_movie + 1].patno = syscom.get_mov_onoff

	// �V�X�e����
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 3].x = math.timetable(syscom.get_se_volume, 0, @slide_vol_pos, [0, 255, @slide_vol_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_vol_sys + 1].patno = syscom.get_se_onoff

	// �L���������F�̂�
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 3].x = math.timetable(syscom.get_charakoe_volume(00), 0, @slide_chara_pos, [0, 255, @slide_chara_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_chara_nono + 1].patno = syscom.get_charakoe_onoff(00)
	
	// �z
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 3].x = math.timetable(syscom.get_charakoe_volume(02), 0, @slide_chara_pos, [0, 255, @slide_chara_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_chara_rin + 1].patno = syscom.get_charakoe_onoff(02)
	
	// �ڗ����
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 3].x = math.timetable(syscom.get_charakoe_volume(01), 0, @slide_chara_pos, [0, 255, @slide_chara_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_chara_ruri + 1].patno = syscom.get_charakoe_onoff(01)

	// �݂邭
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 3].x = math.timetable(syscom.get_charakoe_volume(03), 0, @slide_chara_pos, [0, 255, @slide_chara_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_chara_milk + 1].patno = syscom.get_charakoe_onoff(03)

	// �e���A��
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 3].x = math.timetable(syscom.get_charakoe_volume(04), 0, @slide_chara_pos, [0, 255, @slide_chara_pos + @slide_width])
	excall.stage[$i].object[@obj_config].child[@c_chara_other + 1].patno = syscom.get_charakoe_onoff(04)

	// �Đ��ݒ�
	excall.stage[$i].object[@obj_config].child[@c_koe_keep].patno = syscom.get_koe_dont_stop_onoff


}


// =========================================================
// �܂܃��[�h�^�C�v
// =========================================================
command $mama_mode_type(property $i){

	excall.stage[$i].object[@obj_config].child[@c_mama_dummy].patno = 1 - @mama_type
	excall.stage[$i].object[@obj_config].child[@c_mama_crash].patno = 2 + @mama_type

	excall.stage[$i].object[@obj_config].child[@c_mama_dummy + 1 - @mama_type].set_button(@btn_mama_dummy + 1 - @mama_type, 0, 2, 0)
	excall.stage[$i].object[@obj_config].child[@c_mama_dummy + @mama_type].clear_button
}


// =========================================================
// �܂܃T���l�C��
// =========================================================
command $mama_thum_update(property $i){

	for(l[0] = 0, l[0] < @mama_thum_num, l[0] += 1){
		excall.stage[$i].object[@obj_config].child[@c_mama_thum_start + l[0]].create(_config_btn_mama_thum, 1, 208 + 138 * l[0], 300, l[0])
		excall.stage[$i].object[@obj_config].child[@c_mama_thum_start + l[0]].set_button(@btn_mama_thum_start + l[0], 0, 2, 0)
		excall.stage[$i].object[@obj_config].child[@c_mama_thum_start + l[0]].child.resize(1)
		excall.stage[$i].object[@obj_config].child[@c_mama_thum_start + l[0]].child[0].create(_config_btn_mama_thum_fr, 0, -3, -3)
	}
	
	excall.stage[$i].object[@obj_config].child[@c_mama_thum_start + @mama_dummy].clear_button
	excall.stage[$i].object[@obj_config].child[@c_mama_thum_start + @mama_dummy].child[0].disp = 1

}

